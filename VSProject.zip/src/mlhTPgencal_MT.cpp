/* Maximum likelihood method with n-state linear kinetic model
   There are 3n-2 fitting parameters:
   parameters 1 to n: FRET efficiency E(1) ~ E(n);
   parameters n+1 to 2n-1: k(1) ~ k(n-1), k(1) is the sum of foward and backward rates between state 1 and 2;
   parameters 2n to 3n-2: f(1) ~ f(n-1), p(1) = f(1), p(2) = [1-f(1)]*f(2), p(3) = [1-f(1)]*[1-f(2)]*f(3), ...
   p(n) = [1-f(1)]*[1-f(2)]* ... *[1-f(n-1)].
   Instead of population p, a relative fraction f is used. f(i) = p(i)/(p(i)+p(i+1). Each f ranges from 0 to 1. */

#include "mlhTPgencal_MT.h"

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}

/* The gateway function */
MEXFUNCTION_LINKAGE
void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch(nrhs) 
	{
		case 7: //
		{
			//MATLAB variables
			c_data *input_data=new c_data;

			if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
			{
				mexErrMsgTxt("Error: input parameters are inconsistent!");
				return;
			}

			/* Customization starts */
//			input_data->number_of_states = (input_data->number_of_parameters + 2)/3;
			input_data->number_of_colors = 2;
			/* Customization ends*/

			gsl_vector * output_data;
			if (input_data->number_of_evaluations > 2)
			{
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else
			{
				if (input_data->number_of_evaluations == 2) {
					input_data->number_of_evaluations = 1;
					output_data = calc_mlh_sub(input_data);
					output_to_matlab(output_data, plhs);
				}
				else {
					output_data = calc_mlh(input_data);
					output_to_matlab(output_data, plhs);
				}
			}

			//free variables
			input_data_free(input_data);
			gsl_vector_free(output_data);
		}break;

		default:
		{
			mexErrMsgTxt("Error: number of input args should be 5!");
		}
	}
	return;
}

/* Main routines */
unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//acquire real parameter
	LUbound_conv(mt_param->param, input_data, pconv);

	/* Customization starts */
	double *ratemat0in = input_data->ratemat0in;
	double *statevec = input_data->statevec;
	double *effn = new double[numS];

	for (mwSize i = 0; i < numS; i++) {
		effn[i] = gsl_vector_get(pconv, i);
	}

	gsl_vector *peq = m_vars->peq;//initialize peq
	gsl_matrix *ratemat0 = m_vars->ratemat0;
	for (mwSize i = 0; i < numS; i++) {
		for (mwSize j = 0; j < numS; j++) {
			gsl_matrix_set(ratemat0, i, j, ratemat0in[j * numS + i]);
		}
		gsl_vector_set(peq, i, statevec[i]);
	}

	//Do diagonalization
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;
	gsl_vector_complex *eigen_values = m_vars->eigen_values;
	gsl_matrix_complex *eigen_mat = m_vars->eigen_mat;
	gsl_matrix_complex *inv_eigen_mat = m_vars->inv_eigen_mat;

	gsl_eigen_nonsymmv(ratemat0, eigen_values, eigen_mat, W);
	gsl_linalg_inv(eigen_mat, inv_eigen_mat);

	//FRET matrix
	gsl_matrix_complex **Emat = m_vars->Emat;
	gsl_matrix_complex **Emat_diag = m_vars->Emat_diag;

	for (mwSize i = 0; i < numC; i++)
	{
		gsl_matrix_complex_set_zero(Emat[i]);
		gsl_matrix_complex_set_zero(Emat_diag[i]);
	}

	/* Customization starts */
	for (mwSize i = 0; i < numS; i++) {
		gsl_matrix_complex_set(Emat_diag[0], i, i, gsl_r2c(effn[i]));
		gsl_matrix_complex_set(Emat_diag[1], i, i, gsl_r2c(1 - effn[i]));
	}
	/* Customization ends */

	//change to eigenspace coordinate
	for (mwSize i = 0; i < numC; i++)
	{
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[i], eigen_mat, GSL_COMPLEX_ZERO, Emat[i]);
		gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, Emat[i], GSL_COMPLEX_ZERO, Emat_diag[i]);
	}

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub = m_vars->probonesub;
	gsl_vector_complex *probonesub_t = m_vars->probonesub_t;

	//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;

	mt_param->probeone = 0;
	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{
		for (mwSize i = 0; i < numS; i++)
		{
//			gsl_vector_complex_set(probonesub, i, gsl_r2c(gsl_vector_get(peq, i)));
			gsl_vector_complex_set(probonesub, i, gsl_r2c(statevec[numS + i]));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

		logamp = 0;
		photon_interval = 1;
		normprobone = 1;
		photon_color = 1;

		//for burst length
		for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit. 100 ns -> 1 ms
			photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

			//set ratemat value
			for (mwSize i = 0; i < numS; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_values, i), photon_interval));
				gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
			}

/*			//get ratemat X E
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, ratemat, Emat_diag[photon_color - 1], GSL_COMPLEX_ZERO, ratemat_x_E);

			//probonesub_t: previous probonesub, probonesub: new one
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat_x_E, probonesub_t, GSL_COMPLEX_ZERO, probonesub); */

			//probonesub_t: previous probonesub, probonesub: new one, 25% reduction in computation time compared to matrix multiplication X E above
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

			if ((ii + 1) % 30 == 0)
			{
//				normprobone = gsl_vector_complex_norm(probonesub);
//				gsl_vector_complex_scale(probonesub, gsl_r2c(1 / normprobone));
				normprobone = gsl_vector_complex_norm(probonesub_t);
				gsl_vector_complex_scale(probonesub_t, gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}

			//update probonesub
//			gsl_vector_complex_memcpy(probonesub_t, probonesub);
		}
		gsl_vector_complex_memcpy(probonesub, probonesub_t);

		//the last photon color
		photon_color = frburstdata[frburst_len_m*(frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_mat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

//		mt_param->probeone += -log(gsl_vector_complex_sum(probonesub)) - logamp;

		double sumtmp = 0;
		for (mwSize i = 0; i < numS; i++) {
			sumtmp += gsl_complex_abs(gsl_vector_complex_get(probonesub, i)) * statevec[2 * numS + i];
		}
		mt_param->probeone += -log(sumtmp) - logamp;
	}

//	delete(effn);

	_endthread(); // will terminate this function
	return 1; //should not be executed
}