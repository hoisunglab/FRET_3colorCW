/* 3-color maximum likelihood method with n-state linear kinetic model + acceptor blinking
There are 4n+2 fitting parameters:
parameters 1 to n: 3-color FRET efficiency E1(1) ~ E1(n);
parameters n+1 to 2n: 3-color FRET efficiency E2(1) ~ E2(n);
parameters 2n+1 to 3n-1: k(1) ~ k(n-1), k(1) is the sum of foward and backward rates between state 1 and 2;
parameters 3n to 4n-2: f(1) ~ f(n-1), p(1) = f(1), p(2) = [1-f(1)]*f(2), p(3) = [1-f(1)]*[1-f(2)]*f(3), ...
p(n) = [1-f(1)]*[1-f(2)]* ... *[1-f(n-1)].
Instead of population p, a relative fraction f is used. f(i) = p(i)/(p(i)+p(i+1). Each f ranges from 0 to 1. 
Parameters 4n-1 and 4n: rates from the dark to bright state of A1 and A2
Parameters 4n+1 and 4n+2: bright state populations of A1 and A2 at the reference photon count rate */

#include "mlhrateeiglingen3c1ExABI_MT.h"


/* The gateway function */
DLL_EXPORT_SYM
void mexFunction(int nlhs, mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch (nrhs)
	{
	case 7: //
	{
		//MATLAB variables
		c_data *input_data = new c_data;
		if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
		{
			mexErrMsgTxt("Error: input parameters are inconsistent!");
			return;
		}

		/* Customization starts */
		input_data->number_of_states = (input_data->number_of_parameters - 2) * 4 / 4;
		input_data->number_of_colors = 3;
		/* Customization ends*/

		gsl_vector * output_data;
		if (input_data->number_of_evaluations > 2)
		{
			output_data = calc_mlh_sub(input_data);
			output_to_matlab(output_data, plhs);
		}
		else
		{
			if (input_data->number_of_evaluations == 2) {
				input_data->number_of_evaluations = 1;
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else {
				output_data = calc_mlh(input_data);
				output_to_matlab(output_data, plhs);
			}
		}

		//free variables
		input_data_free(input_data);
		gsl_vector_free(output_data);
	}break;

	default:
	{
		mexErrMsgTxt("Error: number of input args should be 7!");
	}
	}
	return;
}

/* Main routines */

bool input_from_matlab(const mxArray *prhs[], c_data *input_data)
// Initialize input data using MATLAB input
{
	input_data->initparams = mxGetPr(prhs[0]);
	input_data->LUbounds = mxGetPr(prhs[1]);
	input_data->frburstdata = mxGetPr(prhs[2]);
	input_data->cumindex = mxGetPr(prhs[3]);
	input_data->indexone = mxGetPr(prhs[4]);
	input_data->cntrate = mxGetPr(prhs[5]);
	input_data->fixparam = mxGetPr(prhs[6]);

	input_data->number_of_parameters = mxGetM(prhs[0]);

	/* Customization starts */
//	input_data->number_of_states = 4;
//	input_data->number_of_colors = 2;
	/* Customization ends*/

	input_data->number_of_evaluations = mxGetN(prhs[0]);

	input_data->cumindex_len = mxGetNumberOfElements(prhs[3]);
	input_data->indexone_len = mxGetNumberOfElements(prhs[4]);
	input_data->frburst_len_m = mxGetM(prhs[2]);
	input_data->frburst_len_n = mxGetN(prhs[2]);

	input_data->L_bound = gsl_vector_calloc(input_data->number_of_parameters);
	input_data->U_bound = gsl_vector_calloc(input_data->number_of_parameters);

	for (mwSize i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(input_data->L_bound, i, input_data->LUbounds[i]);
		gsl_vector_set(input_data->U_bound, i, input_data->LUbounds[input_data->number_of_parameters + i]);
	}

	/* Consistency check */
	// number_of_parameters should be consistent
	if (mxGetM(prhs[1]) != input_data->number_of_parameters)
	{
		mexPrintf("numel(LUbound)=%d, numOfParam=%d\n", mxGetM(prhs[1]), input_data->number_of_parameters);
		return true;
	}
	// A parameter should be between its LU bound
	for (size_t i = 0; i < input_data->number_of_parameters; i++)
	{
		if (input_data->initparams[i] < input_data->LUbounds[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->initparams[i], input_data->LUbounds[i]);
			return true;
		}
		if (input_data->LUbounds[input_data->number_of_parameters + i] < input_data->initparams[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->LUbounds[input_data->number_of_parameters + i], input_data->initparams[i]);
			return true;
		}

	}
	return false;
}

double mlhratesub(const gsl_vector * param, void * input_pack)
// Return MLE for the given parammeter and c_data. The function to be minimized.
{
#ifdef _MLH_MT
	mt_vars *mt_param = (mt_vars *)input_pack;
	c_data *input_data = mt_param[0].input_data;

	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_memcpy(mt_param[i].param, param);
		mt_param[i].curThread = i;
		Threads[i] = (HANDLE)_beginthreadex(NULL, 0, &analysisThread, (void *)&mt_param[i], 0, &threadIDs[i]);
	}
	for (int i = 0; i < maxThread; i++)
	{
		WaitForSingleObject(Threads[i], INFINITE);
	}

	for (int i = 1; i < maxThread; i++) mt_param[0].probeone += mt_param[i].probeone; //sum up probeone of each thread
	return mt_param[0].probeone;
#else
	mlh_param_pack *m_pack = (mlh_param_pack *)input_pack;
	c_data *input_data = m_pack->data;
	mlh_vars *m_vars = m_pack->vars;

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//gsl_vector_calloc(param->size);
									  //acquire real parameter pconv from param
	LUbound_conv(param, input_data, pconv);

	/* Customization starts */
	double eff1 = gsl_vector_get(pconv, 0);
	double eff2 = gsl_vector_get(pconv, 1);
	double effD = gsl_vector_get(pconv, 2); // E for acceptor dark state
	double ratesumF = gsl_vector_get(pconv, 3); // protein kinetics ratesum
	double kB = gsl_vector_get(pconv, 4); //ktobrt
	double pF = gsl_vector_get(pconv, 5); // pF=kf/(kf+ku)
	double pB0 = gsl_vector_get(pconv, 6); // pB0=kb/(kb+kd0)
										   /* Customization ends */

										   /* Get variables from m_vars */
	gsl_vector *peq = m_vars->peq;
	gsl_matrix *ratemat0 = m_vars->ratemat0;

	// Get diagonalization workspace
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;
	gsl_vector_complex *eigen_values = m_vars->eigen_values;
	gsl_matrix_complex *eigen_mat = m_vars->eigen_mat;
	gsl_matrix_complex *inv_eigen_mat = m_vars->inv_eigen_mat;

	// Get the allocated FRET matrices
	gsl_matrix_complex **Emat = m_vars->Emat;
	gsl_matrix_complex **Emat_diag = m_vars->Emat_diag;

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub = m_vars->probonesub;//gsl_vector_complex_calloc(numS);
	gsl_vector_complex *probonesub_t = m_vars->probonesub_t;//gsl_vector_complex_calloc(numS);

															//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	double *cntrate = input_data->cntrate;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;//gsl_matrix_complex_calloc(numS,numS);
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;//gsl_matrix_complex_calloc(numS,numS);
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	double probeone = 0;
	double ratesumB = 1000;
	double pB = 1;
	double kD = 1000;

	for (mwSize k = 0; k<indexone_len; k++)
	{
		kD = kB*(1 - pB0) / pB0*cntrate[k] / 100; // for 100 photons per ms countrate unit.
		ratesumB = kB + kD;
		pB = kB / ratesumB;
		/* Customization starts */
		//initialize peq
		gsl_vector_set(peq, 0, pB*pF);
		gsl_vector_set(peq, 1, pB*(1 - pF));
		gsl_vector_set(peq, 2, (1 - pB)*pF);
		gsl_vector_set(peq, 3, (1 - pB)*(1 - pF));

		ratemat0_init(ratemat0, pF, pB, ratesumF, ratesumB);
		/* Customization ends */

		//Do diagonalization
		gsl_eigen_nonsymmv(ratemat0, eigen_values, eigen_mat, W); // get eigen values and eigen vector matrix
		gsl_linalg_inv(eigen_mat, inv_eigen_mat); // get inverse of the eigen vector matrix

												  // Set FRET matrix
		for (mwSize i = 0; i<numC; i++)
		{
			gsl_matrix_complex_set_zero(Emat[i]);
			gsl_matrix_complex_set_zero(Emat_diag[i]);
		}

		/* Customization starts */
		gsl_matrix_complex_set(Emat_diag[0], 0, 0, gsl_r2c(eff1));
		gsl_matrix_complex_set(Emat_diag[0], 1, 1, gsl_r2c(eff2));
		gsl_matrix_complex_set(Emat_diag[0], 2, 2, gsl_r2c(effD));
		gsl_matrix_complex_set(Emat_diag[0], 3, 3, gsl_r2c(effD));

		gsl_matrix_complex_set(Emat_diag[1], 0, 0, gsl_r2c(1 - eff1));
		gsl_matrix_complex_set(Emat_diag[1], 1, 1, gsl_r2c(1 - eff2));
		gsl_matrix_complex_set(Emat_diag[1], 2, 2, gsl_r2c(1 - effD));
		gsl_matrix_complex_set(Emat_diag[1], 3, 3, gsl_r2c(1 - effD));
		/* Customization ends */

		//change to eigenspace coordinate
		for (mwSize i = 0; i<numC; i++)
		{
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[i], eigen_mat, GSL_COMPLEX_ZERO, Emat[i]);
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, Emat[i], GSL_COMPLEX_ZERO, Emat_diag[i]);
		}
#ifdef _MLH_CUDA

		for (int j = 0; j<numS; j++)
		{
			for (int l = 0; l<numS; l++)
			{
				for (mwSize i = 0; i < numC; i++)
				{
					m_vars->h_Emat[k*numC*numS*numS + i*numS*numS + numS*j + l] = GSL_REAL(gsl_matrix_complex_get(Emat_diag[i], j, l));
				}
				m_vars->h_eigenmat[k*numS*numS + numS*j + l] = GSL_REAL(gsl_matrix_complex_get(eigen_mat, j, l));
				m_vars->h_inveigenmat[k*numS*numS + numS*j + l] = GSL_REAL(gsl_matrix_complex_get(inv_eigen_mat, j, l));
			}
			m_vars->h_rateeig[k*numS + j] = GSL_REAL(gsl_vector_complex_get(eigen_values, j));
			m_vars->h_peq[k*numS + j] = gsl_vector_get(peq, j);
		}
#endif

#ifndef _MLH_CUDA
		for (mwSize i = 0; i<numS; i++)
		{
			gsl_vector_complex_set(probonesub, i, gsl_r2c(gsl_vector_get(peq, i)));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);



		double logamp = 0;
		double photon_interval = 1;
		double normprobone = 1;
		mwSize photon_color = 1;

		//for burst length
		for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii<cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit
			photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

			//set ratemat value
			for (mwSize i = 0; i<numS; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_values, i), photon_interval));
				gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
			}

			//get ratemat X E
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, ratemat, Emat_diag[photon_color - 1], GSL_COMPLEX_ZERO, ratemat_x_E);

			//probonesub_t: previous probonesub, probonesub: new one
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat_x_E, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

			if ((ii + 1) % 30 == 0)
			{
				normprobone = gsl_vector_complex_norm(probonesub);
				gsl_vector_complex_scale(probonesub, gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}

			//update probonesub
			gsl_vector_complex_memcpy(probonesub_t, probonesub);

		}

		//the last photon color
		photon_color = frburstdata[frburst_len_m*(frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_mat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

		probeone += -log(gsl_vector_complex_sum(probonesub)) - logamp;
#endif
	}

	return probeone;
#endif
#ifdef _MLH_CUDA
	probeone = calcProbeoneCU(m_pack);
#endif

}


unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//gsl_vector_calloc(param->size);
									  //acquire real parameter pconv from param
	LUbound_conv(mt_param->param, input_data, pconv);

	/* Customization starts */
	mwSize numAcc = 2;	// Number of acceptor (We may try 4-color later)
	mwSize numSb = numS / 4;
	double *eff1s1 = new double[numSb];      // 3-color apparent E1
	double *eff2s1 = new double[numSb];      // 3-color apparent E2
	double *effs2 = new double[numSb];      // Apparent E1 for DA1 part (= (A1+A2)/(D+A1+A2))
	double *effs3 = new double[numSb];      // Apparent E2 for DA2 part (= A2/(D+A1+A2))
	double *ratesumn = new double[numSb];
	double *frn = new double[numSb];
	double frnprod = 1;
	double *fixparam = input_data->fixparam;
	double effD1 = fixparam[0]; // E1 of A1,A2 dark state (= A1/(A2 + A1 + D))
	double effD2 = fixparam[1]; // E2 of A1,A2 dark state (= A2/(A2 + A1 + D)) (depends on the A2-protein concentration)
	double effD12 = fixparam[2*numSb + 2];       // E12 with no A2: A1 leak into A2 channel
	double kB[2]; //ktobrt, kB[0]: A1, kB[1]: A2
	double pB0[2]; // pB0=kb/(kb+kd0), pB0[0]: A1, pB0[1]: A2

	for (mwSize i = 0; i < numSb; i++) {
		eff1s1[i] = gsl_vector_get(pconv, i);
		eff2s1[i] = gsl_vector_get(pconv, numSb + i);
		effs2[i] = fixparam[2 + i];
		effs3[i] = fixparam[numSb + 2 + i];
	}
	for (mwSize i = 0; i < numSb - 1; i++) {
		ratesumn[i] = gsl_vector_get(pconv, 2 * numSb + i);
		frn[i] = gsl_vector_get(pconv, 3 * numSb + i - 1);
	}

	for (mwSize i = 0; i < 2; i++) {
		kB[i] = gsl_vector_get(pconv, 4 * numSb - 2 + i);
		pB0[i] = gsl_vector_get(pconv, 4 * numSb + i);
	}

	double *pF = new double[numSb]; //initialize peq in the bright state
	for (mwSize i = 0; i < numSb - 1; i++) {
		pF[i] = frn[i] * frnprod;
		frnprod *= 1 - frn[i];
	}
	pF[numSb - 1] = frnprod;
	/* Customization ends */

										   /* Get variables from m_vars */
	gsl_vector *peq = m_vars->peq;
	gsl_matrix *ratemat0 = m_vars->ratemat0;

	// Get diagonalization workspace
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;
	gsl_vector_complex *eigen_values = m_vars->eigen_values;
	gsl_matrix_complex *eigen_mat = m_vars->eigen_mat;
	gsl_matrix_complex *inv_eigen_mat = m_vars->inv_eigen_mat;

	// Get the allocated FRET matrices
	gsl_matrix_complex **Emat = m_vars->Emat;
	gsl_matrix_complex **Emat_diag = m_vars->Emat_diag;

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub = m_vars->probonesub;//gsl_vector_complex_calloc(numS);
	gsl_vector_complex *probonesub_t = m_vars->probonesub_t;//gsl_vector_complex_calloc(numS);

															//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	double *cntrate = input_data->cntrate;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;//gsl_matrix_complex_calloc(numS,numS);
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;//gsl_matrix_complex_calloc(numS,numS);
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	mt_param->probeone = 0;
	double ratesumB[2] = { 1000, 1000 };
	double pB[2] = { 1, 1 };
	double kD[2] = { 1000, 1000 };

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;

	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{

		/* Customization starts */
		for (mwSize i = 0; i < numAcc; i++) {
			kD[i] = kB[i] * (1 - pB0[i]) / pB0[i] * cntrate[k] / 100; // for 100 photons per ms countrate unit.
			ratesumB[i] = kB[i] + kD[i];
			pB[i] = kB[i] / ratesumB[i];
		}
		//initialize peq
		gsl_vector_set_zero(peq);
		for (mwSize i = 0; i < numSb; i++) {
			gsl_vector_set(peq, i, pF[i] * pB[0] * pB[1]);
			gsl_vector_set(peq, numSb + i, pF[i] * pB[0] * (1 - pB[1]));
			gsl_vector_set(peq, 2 * numSb + i, pF[i] * (1 - pB[0]) * pB[1]);
			gsl_vector_set(peq, 3 * numSb + i, pF[i] * (1 - pB[0]) * (1 - pB[1]));
		}

		ratemat0_init(ratemat0, pF, pB, ratesumn, ratesumB, numSb, numAcc);
		/* Customization ends */

		//Do diagonalization
		gsl_eigen_nonsymmv(ratemat0, eigen_values, eigen_mat, W); // get eigen values and eigen vector matrix
		gsl_linalg_inv(eigen_mat, inv_eigen_mat); // get inverse of the eigen vector matrix

		// Set FRET matrix
		for (mwSize i = 0; i < numC; i++)
		{
			gsl_matrix_complex_set_zero(Emat[i]);
			gsl_matrix_complex_set_zero(Emat_diag[i]);
		}

		/* Customization starts */
		for (mwSize i = 0; i < numSb; i++) {
			gsl_matrix_complex_set(Emat_diag[0], i, i, gsl_r2c(eff2s1[i]));
			gsl_matrix_complex_set(Emat_diag[1], i, i, gsl_r2c(eff1s1[i]));
			gsl_matrix_complex_set(Emat_diag[2], i, i, gsl_r2c(1 - eff1s1[i] - eff2s1[i]));

			gsl_matrix_complex_set(Emat_diag[0], numSb + i, numSb + i, gsl_r2c(effs2[i] * effD12));
			gsl_matrix_complex_set(Emat_diag[1], numSb + i, numSb + i, gsl_r2c(effs2[i] * (1 - effD12)));
			gsl_matrix_complex_set(Emat_diag[2], numSb + i, numSb + i, gsl_r2c(1 - effs2[i]));

			gsl_matrix_complex_set(Emat_diag[0], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effs3[i]));
			gsl_matrix_complex_set(Emat_diag[1], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effD1*(1 - effs3[i])));
			gsl_matrix_complex_set(Emat_diag[2], 2 * numSb + i, 2 * numSb + i, gsl_r2c((1 - effD1)*(1 - effs3[i])));

			gsl_matrix_complex_set(Emat_diag[0], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD2));
			gsl_matrix_complex_set(Emat_diag[1], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD1));
			gsl_matrix_complex_set(Emat_diag[2], 3 * numSb + i, 3 * numSb + i, gsl_r2c(1 - effD1 - effD2));
		}
		/* Customization ends */

		//change to eigenspace coordinate
		for (mwSize i = 0; i < numC; i++)
		{
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[i], eigen_mat, GSL_COMPLEX_ZERO, Emat[i]);
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, Emat[i], GSL_COMPLEX_ZERO, Emat_diag[i]);
		}

		for (mwSize i = 0; i < numS; i++)
		{
			gsl_vector_complex_set(probonesub, i, gsl_r2c(gsl_vector_get(peq, i)));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

		logamp = 0;

		//for burst length
		for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit
			photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

			//set ratemat value
			for (mwSize i = 0; i < numS; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_values, i), photon_interval));
				gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
			}

/*			//get ratemat X E
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, ratemat, Emat_diag[photon_color - 1], GSL_COMPLEX_ZERO, ratemat_x_E);

			//probonesub_t: previous probonesub, probonesub: new one
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat_x_E, probonesub_t, GSL_COMPLEX_ZERO, probonesub); */

			//probonesub_t: previous probonesub, probonesub: new one, 25% reduction in computation time compared to matrix multiplication X E above
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

			if ((ii + 1) % 30 == 0)
			{
//				normprobone = gsl_vector_complex_norm(probonesub);
//				gsl_vector_complex_scale(probonesub, gsl_r2c(1 / normprobone));
				normprobone = gsl_vector_complex_norm(probonesub_t);
				gsl_vector_complex_scale(probonesub_t, gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}

			//update probonesub
//			gsl_vector_complex_memcpy(probonesub_t, probonesub);
		}
		gsl_vector_complex_memcpy(probonesub, probonesub_t);

		//the last photon color
		photon_color = frburstdata[frburst_len_m*(frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_mat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

		mt_param->probeone += -log(gsl_vector_complex_sum(probonesub)) - logamp;
	}
	//gProbeone[cursor] = probeone;
	//mexPrintf("gProbeone[%d] = %f\n", cursor, probeone);
	delete(eff1s1);
	delete(eff2s1);
	delete(effs2);
	delete(effs3);
	delete(ratesumn);
	delete(frn);
	delete(pF);

	_endthread();
	return 0;
}

gsl_vector *calc_mlh(c_data *input_data)
// Find maximum-likelihood parameter
{
	const gsl_multimin_fminimizer_type *T =
		gsl_multimin_fminimizer_nmsimplex2;//gsl_multimin_fminimizer_nmsimplex2rand
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x, *init_param, *output_param;
	gsl_multimin_function minex_func;

	size_t iter = 0;
	int status;
	double size;

	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;

	init_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}
#endif
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_parameters);

	/* Starting point */
	x = gsl_vector_calloc(input_data->number_of_parameters);

	for (size_t i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(init_param, i, input_data->initparams[i]);
	}
	LUbound_invconv(init_param, input_data, x);

	/* Set initial step sizes to 1 */
	ss = gsl_vector_calloc(input_data->number_of_parameters);
	gsl_vector_set_all(ss, 1.0);

	/* Initialize method and iterate */
	minex_func.n = input_data->number_of_parameters;
	minex_func.f = &mlhratesub;
#ifdef _MLH_MT
	minex_func.params = mt_param;
#else
	minex_func.params = m_pack;
#endif
	s = gsl_multimin_fminimizer_alloc(T, input_data->number_of_parameters);
	gsl_multimin_fminimizer_set(s, &minex_func, x, ss);

	do
	{
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		if (status)
			break;

		size = gsl_multimin_fminimizer_size(s);
		status = gsl_multimin_test_size(size, 1e-3);
		//status = gsl_multimin_test_size (size, 1e-4);

		/*
		if (status == GSL_SUCCESS)
		{
		mexPrintf ("converged to minimum at\n");
		}
		mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
		iter,
		gsl_vector_get (s->x, 0),
		gsl_vector_get (s->x, 1),
		gsl_vector_get (s->x, 2),
		gsl_vector_get (s->x, 3),
		s->fval, size);
		*/

	} while (status == GSL_CONTINUE && iter < 2000);

	if (iter == 2000)
	{
		mexPrintf("Warning: 2000 interations, the minimizer terminated before converge\n");
	}
	/*	  mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
	iter,
	gsl_vector_get (s->x, 0),
	gsl_vector_get (s->x, 1),
	gsl_vector_get (s->x, 2),
	gsl_vector_get (s->x, 3),
	s->fval, size);
	*/
	LUbound_conv(s->x, input_data, output_param);

	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s);
#ifdef _MLH_MT
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
#endif
	free_mlh_vars(m_vars, input_data);
	gsl_vector_free(init_param);
	delete(m_vars);
	delete(m_pack);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

gsl_vector *calc_mlh_sub(c_data *input_data)
// Return logmlh values
{
	gsl_vector *x, *init_param, *output_param;
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	x = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_evaluations);
	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;
	init_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}
#endif

#ifdef _MLH_MT
	void * input_pack = mt_param;
#else
	void * input_pack = m_pack;
#endif
	for (size_t i = 0; i<input_data->number_of_evaluations; i++)
	{
		for (size_t j = 0; j<input_data->number_of_parameters; j++) // interation on initparams
		{
			gsl_vector_set(init_param, j, input_data->initparams[i*input_data->number_of_parameters + j]);
			//mexPrintf("%f\t", input_data->initparams[i*input_data->number_of_parameters + j]);
		}
		//mexPrintf("\n");
		LUbound_invconv(init_param, input_data, x);
		gsl_vector_set(output_param, i, mlhratesub(x, input_pack)); //save mlhratesub value to output_param
	}
	free_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
	delete(m_vars);
	delete(m_pack);
#endif
	gsl_vector_free(init_param);
	gsl_vector_free(x);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

bool output_to_matlab(gsl_vector *output_data, mxArray *plhs[])
// Relay the output parameter to MATLAB
{
	plhs[0] = mxCreateDoubleMatrix(output_data->size, 1, mxREAL);
	double * output = mxGetPr(plhs[0]);
	for (mwSize i = 0; i<output_data->size; i++)
	{
		output[i] = gsl_vector_get(output_data, i);
	}

	return true;
}


/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data)
//pre-allocate dynamic variables that repeatedly used in calc_mlh
{
	const mwSize numC = input_data->number_of_colors;
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;

	//pconv is a converted parameter from by appling LUbound
	var->pconv = gsl_vector_calloc(numP);

	var->peq = gsl_vector_calloc(numS);

	var->ratemat0 = gsl_matrix_calloc(numS, numS);
	var->W = gsl_eigen_nonsymmv_alloc(numS);
	var->eigen_values = gsl_vector_complex_calloc(numS);
	var->eigen_mat = gsl_matrix_complex_calloc(numS, numS);
	var->inv_eigen_mat = gsl_matrix_complex_calloc(numS, numS);

	//FRET matrix
	var->Emat = new gsl_matrix_complex*[numS];
	var->Emat_diag = new gsl_matrix_complex*[numS];

	for (mwSize i = 0; i<numC; i++) // 0: acceptor, 1: donor
	{
		var->Emat[i] = gsl_matrix_complex_calloc(numS, numS);
		var->Emat_diag[i] = gsl_matrix_complex_calloc(numS, numS);
	}

	// MLE cursor vector, probone
	var->probonesub = gsl_vector_complex_calloc(numS);
	var->probonesub_t = gsl_vector_complex_calloc(numS);

	//rate matrix variables
	var->ratemat = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_x_E = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_diag_view = gsl_matrix_complex_diagonal(var->ratemat);
#ifdef _MLH_CUDA
	/* GPU thread structure */
	mwSize indexone_len = input_data->indexone_len;
	//mexPrintf("indexone_len=%d\n", indexone_len);
	var->nDevices = 1;
	cudaGetDeviceCount(&var->nDevices);

	int nDevices = var->nDevices;

	var->grid = (dim3*)malloc(var->nDevices * sizeof(dim3));

	var->blockSize = 32;
	var->block.x = var->blockSize;
	var->block.y = 1;
	var->block.z = 1;

	unsigned int numOfMol = indexone_len;

	for (int i = 0; i < var->nDevices - 1; i++)
	{
		var->grid[i].x = numOfMol / var->nDevices;
		var->grid[i].y = 1;
		var->grid[i].z = 1;
	}
	var->grid[var->nDevices - 1].x = numOfMol - int(numOfMol / var->nDevices) * (var->nDevices - 1);
	var->grid[var->nDevices - 1].y = 1;
	var->grid[var->nDevices - 1].z = 1;

	var->streams = (cudaStream_t*)malloc(var->nDevices * sizeof(cudaStream_t)); //for async calls

																				/* Assign data */

	var->logpArray = (double **)malloc(nDevices * sizeof*var->logpArray);
	var->subMatArray = (double **)malloc(nDevices * sizeof*var->subMatArray);
	var->cumindex = (double **)malloc(nDevices * sizeof*var->cumindex);
	var->indexone = (double **)malloc(nDevices * sizeof*var->indexone);
	var->frburstdata = (double **)malloc(nDevices * sizeof*var->frburstdata);

	var->rateeig = (double **)malloc(nDevices * sizeof*var->rateeig);
	var->h_rateeig = (double *)malloc(numOfMol*numS * sizeof*var->h_rateeig);

	var->d_Emat = (double **)malloc(nDevices * sizeof*var->d_Emat);
	var->h_Emat = (double *)malloc(numOfMol*numC*numS*numS * sizeof*var->h_Emat);

	var->d_peq = (double **)malloc(nDevices * sizeof*var->d_peq);
	var->h_peq = (double *)malloc(numOfMol*numS * sizeof*var->h_peq);

	var->eigenmat = (double **)malloc(nDevices * sizeof*var->eigenmat);
	var->h_eigenmat = (double *)malloc(numOfMol*numS*numS * sizeof*var->h_eigenmat);

	var->inveigenmat = (double **)malloc(nDevices * sizeof*var->inveigenmat);
	var->h_inveigenmat = (double *)malloc(numOfMol*numS*numS * sizeof*var->h_inveigenmat);

	var->expRatemat = (double**)malloc(nDevices * sizeof*var->expRatemat);
	var->kXE = (double**)malloc(nDevices * sizeof*var->kXE);
	var->subMat = (double**)malloc(nDevices * sizeof*var->subMat);
	var->subMatTemp = (double**)malloc(nDevices * sizeof*var->subMatTemp);


	var->proboneT = (double*)malloc(numOfMol * sizeof*var->proboneT);

	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		cudaCheck(cudaStreamCreate(&(var->streams[i])));

		cudaCheck(cudaMalloc(&var->logpArray[i], var->grid[i].x*var->blockSize * sizeof*var->logpArray[i]));
		cudaCheck(cudaMemset(var->logpArray[i], 0, var->grid[i].x*var->blockSize * sizeof*var->logpArray[i]));
		cudaCheck(cudaMalloc(&var->subMatArray[i], var->grid[i].x*var->blockSize*numS*numS * sizeof*var->subMatArray[i]));
		cudaCheck(cudaMemset(var->subMatArray[i], 0, var->grid[i].x*var->blockSize*numS*numS * sizeof*var->subMatArray[i]));
		cudaCheck(cudaMalloc(&var->cumindex[i], input_data->cumindex_len * sizeof*var->cumindex[i]));
		cudaCheck(cudaMemcpy(var->cumindex[i], input_data->cumindex, input_data->cumindex_len * sizeof*var->cumindex[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMalloc(&var->indexone[i], input_data->indexone_len * sizeof*var->indexone[i]));
		cudaCheck(cudaMemcpy(var->indexone[i], input_data->indexone, input_data->indexone_len * sizeof*var->indexone[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMalloc(&var->frburstdata[i], input_data->frburst_len_m*input_data->frburst_len_n * sizeof*var->frburstdata[i]));
		cudaCheck(cudaMemcpy(var->frburstdata[i], input_data->frburstdata, input_data->frburst_len_m*input_data->frburst_len_n * sizeof*var->frburstdata[i], cudaMemcpyHostToDevice));

		cudaCheck(cudaMalloc(&var->rateeig[i], numOfMol*numS * sizeof*var->rateeig[i]));
		cudaCheck(cudaMalloc(&var->d_Emat[i], numOfMol*numC*numS*numS * sizeof*var->d_Emat[i]));

		cudaCheck(cudaMalloc(&var->d_peq[i], numOfMol*numS * sizeof*var->d_peq[i]));

		cudaCheck(cudaMalloc(&var->eigenmat[i], numOfMol*numS*numS * sizeof*var->eigenmat[i]));

		cudaCheck(cudaMalloc(&var->inveigenmat[i], numOfMol*numS*numS * sizeof*var->inveigenmat[i]));

		cudaCheck(cudaMalloc(&var->expRatemat[i], var->grid[i].x*var->blockSize*numS*numS * sizeof*var->expRatemat[i]));
		cudaCheck(cudaMemset(var->expRatemat[i], 0, var->grid[i].x*var->blockSize*numS*numS * sizeof*var->expRatemat[i]));
		cudaCheck(cudaMalloc(&var->kXE[i], var->grid[i].x*var->blockSize*numS*numS * sizeof*var->kXE[i]));
		cudaCheck(cudaMalloc(&var->subMat[i], var->grid[i].x*var->blockSize*numS*numS * sizeof*var->subMat[i]));
		cudaCheck(cudaMalloc(&var->subMatTemp[i], var->grid[i].x*var->blockSize*numS*numS * sizeof*var->subMatTemp[i]));
	}
#endif
	return false;
}

bool free_mlh_vars(mlh_vars *var, const c_data *input_data)
{
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;
	const mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector_free(var->pconv);
	gsl_vector_free(var->peq);

	gsl_matrix_free(var->ratemat0);
	gsl_eigen_nonsymmv_free(var->W);
	gsl_vector_complex_free(var->eigen_values);
	gsl_matrix_complex_free(var->eigen_mat);
	gsl_matrix_complex_free(var->inv_eigen_mat);

	//FRET matrix

	for (mwSize i = 0; i<numC; i++)
	{
		gsl_matrix_complex_free(var->Emat[i]);
		gsl_matrix_complex_free(var->Emat_diag[i]);
	}

	delete(var->Emat);
	delete(var->Emat_diag);

	// MLE cursor vector, probone
	gsl_vector_complex_free(var->probonesub);
	gsl_vector_complex_free(var->probonesub_t);

	//rate matrix variables
	gsl_matrix_complex_free(var->ratemat);
	gsl_matrix_complex_free(var->ratemat_x_E);
#ifdef _MLH_CUDA
	//free device
	int nDevices = var->nDevices;
	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		cudaCheck(cudaFree(var->logpArray[i]));
		cudaCheck(cudaFree(var->subMatArray[i]));
		cudaCheck(cudaFree(var->cumindex[i]));
		cudaCheck(cudaFree(var->indexone[i]));
		cudaCheck(cudaFree(var->frburstdata[i]));

		cudaCheck(cudaFree(var->rateeig[i]));
		cudaCheck(cudaFree(var->d_Emat[i]));

		cudaCheck(cudaFree(var->d_peq[i]));
		cudaCheck(cudaFree(var->eigenmat[i]));
		cudaCheck(cudaFree(var->inveigenmat[i]));

		cudaCheck(cudaFree(var->expRatemat[i]));
		cudaCheck(cudaFree(var->kXE[i]));
		cudaCheck(cudaFree(var->subMat[i]));
		cudaCheck(cudaFree(var->subMatTemp[i]));
	}
	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		cudaCheck(cudaStreamDestroy((var->streams[i])));
	}

	//free host

	free(var->logpArray);
	free(var->subMatArray);
	free(var->cumindex);
	free(var->indexone);
	free(var->frburstdata);

	free(var->rateeig);
	free(var->h_rateeig);

	free(var->d_Emat);
	free(var->h_Emat);

	free(var->d_peq);
	free(var->h_peq);

	free(var->eigenmat);
	free(var->h_eigenmat);

	free(var->inveigenmat);
	free(var->h_inveigenmat);

	free(var->expRatemat);
	free(var->kXE);
	free(var->subMat);
	free(var->subMatTemp);

	free(var->proboneT);

	free(var->streams);
	free(var->grid);
#endif
	return false;
}

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const double *pF, const double *pB, const double *ratesumn, const double *ratesumB, const mwSize numSb, const mwSize numAcc)
/* Customization ends */
// initialize the ratematrix using p_eq and ratesum
{
	/* Customization starts */
	double kB[2];
	double kD[2];

	for (mwSize i = 0; i < numAcc; i++) {
		kB[i] = ratesumB[i] * pB[i];
		kD[i] = ratesumB[i] * (1 - pB[i]);
	}
	
	gsl_matrix_set_zero(ratemat0);
	for (mwSize i = 0; i < numSb - 1; i++) {
		gsl_matrix *ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector *peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, pF[i]);
		gsl_vector_set(peqtemp, 1, pF[i + 1]);
		gsl_vector_scale(peqtemp, 1 / (pF[i] + pF[i + 1]));
		ratemat2st_init(ratemattemp, peqtemp, ratesumn[i]);

		for (mwSize j = 0; j < 4; j++) {
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j) + gsl_matrix_get(ratemattemp, 0, 0));
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 0, 1));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j) + gsl_matrix_get(ratemattemp, 1, 0));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 1, 1));
		}

		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}
	for (mwSize i = 0; i < 2*numSb; i++) {
		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) - kD[0]);
		gsl_matrix_set(ratemat0, i + 2*numSb, i, gsl_matrix_get(ratemat0, i + 2*numSb, i) + kD[0]);
		gsl_matrix_set(ratemat0, i, i + 2*numSb, gsl_matrix_get(ratemat0, i, i + 2*numSb) + kB[0]);
		gsl_matrix_set(ratemat0, i + 2*numSb, i + 2*numSb, gsl_matrix_get(ratemat0, i + 2*numSb, i + 2*numSb) - kB[0]);
	}
	for (mwSize i = 0; i < numSb; i++) {
		for (mwSize j = 0; j < 2; j++) {
			gsl_matrix_set(ratemat0, i + 2*numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + 2 * numSb*j) - kD[1]);
			gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j) + kD[1]);
			gsl_matrix_set(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j) + kB[1]);
			gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j) - kB[1]);
		}
	}
	/* Customization ends */

	return false;
}

/* Customization starts */
bool ratemat2st_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}
/* Customization ends */

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert unbound param to bound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);

	gsl_vector_memcpy(temp, param);
	gsl_vector_mul(temp, param); //temp=param^2
	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound); //pconv=U-L
	gsl_vector_add_constant(temp, 1.0);//temp=1+param^2;
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(1+param^2);
	gsl_vector_add(pconv, input_data->L_bound);//pconv=(U-L)/(1+param^2)+L;

	gsl_vector_free(temp);
	return 0;
}

int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert bound param to unbound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);
	gsl_vector_sub(temp, input_data->L_bound);//temp=param-L

	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound);//pconv=U-L
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(param-L);
	gsl_vector_add_constant(pconv, -1);//pconv=(U-L)/(param-L)-1
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, sqrt(gsl_vector_get(pconv, i)));
	}
	gsl_vector_free(temp);
	return 0;
}

/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A)
//calculate inverse matrix of A using LU decomposition
{
	gsl_matrix_complex *A_copy = gsl_matrix_complex_calloc(A->size1, A->size2);
	gsl_matrix_complex_memcpy(A_copy, A);
	gsl_permutation *p = gsl_permutation_calloc(A->size1);
	int signum = 0;
	gsl_linalg_complex_LU_decomp(A_copy, p, &signum);
	gsl_linalg_complex_LU_invert(A_copy, p, inv_A);

	gsl_matrix_complex_free(A_copy);
	gsl_permutation_free(p);
	return 0;
}

gsl_complex gsl_r2c(double r)
//convert real variable r to complex variable r+0i
{
	gsl_complex c;
	GSL_SET_COMPLEX(&c, r, 0);
	return c;
}


double gsl_vector_complex_norm(gsl_vector_complex *v)
//calculate norm of vector v
{
	double norm_square = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		norm_square += gsl_complex_abs2(gsl_vector_complex_get(v, i));
	}
	return sqrt(norm_square);
}

double gsl_vector_complex_sum(gsl_vector_complex *v)
//summate absolute value of all element of v
{
	double sum = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		sum += gsl_complex_abs(gsl_vector_complex_get(v, i));
	}
	return sum;
}

/* Destructor */

bool input_data_free(c_data * input_data)
// free input_data
{
	gsl_vector_free(input_data->L_bound);
	gsl_vector_free(input_data->U_bound);
	delete(input_data);
	return true;
}


#ifdef _MLH_CUDA
__global__ void calcProbeoneSubMatrix(double *logpArray, double *subMatArray, double *cumindex, double *indexone, double *frburstdata, \
	double *rateeig0, double *Emat0, double *peq0, mwSize numS, int molOffset, mwSize frburst_len_m, mwSize frburst_len_n, \
	double *expRatemat0, double *kXE0, double *subMat0, double *subMatTemp0, mwSize numC)
{
	int k = blockIdx.x + molOffset; //molNum
	int threadI = threadIdx.x;
	int totalThread = blockDim.x;

	mwSize matOffset = numS*numS*(blockDim.x*blockIdx.x + threadIdx.x); // sum over a device.
	mwSize matMolOffset = numS*numS*k;

	mwSize firstPhotonIndex = cumindex[mwSize(indexone[k] - 1)];
	mwSize lastPhotonIndex = cumindex[mwSize(indexone[k] - 1) + 1] - 1;
	mwSize totalPhoton = lastPhotonIndex - firstPhotonIndex + 1 - 1; // need special calc. on the last photon
	mwSize photonsPerThread = round(double(totalPhoton) / double(totalThread + 2));
	mwSize startCalcIndex = firstPhotonIndex + threadI*photonsPerThread;
	mwSize endCalcIndex = firstPhotonIndex + (threadI + 1)*photonsPerThread - 1;
	if (threadI == totalThread - 1) endCalcIndex = lastPhotonIndex - 1;

	int ii = startCalcIndex;
	double photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
	photon_interval *= 1E-4; // in ms unit
	mwSize photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

	double *rateeig = rateeig0 + numS*k;
	double *Emat = Emat0 + numC*matMolOffset;
	double *peq = peq0 + +numS*k;

	double *expRatemat = expRatemat0 + matOffset;
	double *kXE = kXE0 + matOffset;
	double *subMat = subMat0 + matOffset;
	double *subMatTemp = subMatTemp0 + matOffset;

	for (int i = 0; i < numS*numS; i++)
	{
		expRatemat[i] = 0;
		kXE[i] = 0;
		subMat[i] = 0;
		subMatTemp[i] = 0;
	}

	for (int i = 0; i < numS; i++)
	{
		expRatemat[numS*i + i] = exp(photon_interval*rateeig[i]);
	}
	double *EmatOne = Emat + numS*numS*(photon_color - 1);
	cudaMatrixAxB(expRatemat, EmatOne, subMat, numS, numS, numS); // set expRatemat * EmatOne = subMat

	logpArray[blockDim.x*blockIdx.x + threadIdx.x] = 0;

	for (ii = startCalcIndex + 1; ii <= endCalcIndex; ii++)
	{
		photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
		photon_interval *= 1E-4;
		photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

		EmatOne = Emat + numS*numS*(photon_color - 1);
		for (int i = 0; i < numS; i++)
		{
			expRatemat[numS*i + i] = exp(photon_interval*rateeig[i]);
		}
		cudaMatrixAxB(expRatemat, EmatOne, kXE, numS, numS, numS);
		cudaMatrixAxB(kXE, subMat, subMatTemp, numS, numS, numS);
		for (int i = 0; i < numS*numS; i++)
		{
			subMat[i] = subMatTemp[i];
		}

		if ((ii - startCalcIndex) % 15 == 0) logpArray[blockDim.x*blockIdx.x + threadIdx.x] += log(roughNorm(subMat, numS, numS)); // logpArray assigned to each threads, per device
	}

	for (int i = 0; i < numS*numS; i++)
	{
		subMatArray[matOffset + i] = subMat[i];
	}

	return;
}

__global__ void calcProbeone(double *logpArray, double *subMatArray, double *cumindex, double *indexone, double *frburstdata, \
	double *rateeig0, double *Emat0, double *peq0, mwSize numS, int molOffset, mwSize frburst_len_m, mwSize frburst_len_n, \
	double *eigenmat0, double *inveigenmat0, unsigned int blockSize, double *subMat0, double *subMatTemp0, mwSize numC)
{
	int k = blockIdx.x + molOffset; //molNum
									//int threadI = threadIdx.x;
									//int totalThread = blockSize;

	mwSize matOffset = numS*numS*(blockIdx.x*blockSize); // sum over a device.
	mwSize matMolOffset = numS*numS*k;

	mwSize firstPhotonIndex = cumindex[mwSize(indexone[k] - 1)];
	mwSize lastPhotonIndex = cumindex[mwSize(indexone[k] - 1) + 1] - 1;

	int ii = lastPhotonIndex;
	mwSize photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

	double *Emat = Emat0 + numC*matMolOffset;
	double *peq = peq0 + +numS*k;

	double *eigenmat = eigenmat0 + matMolOffset;
	double *inveigenmat = inveigenmat0 + matMolOffset;

	double *subMat = subMat0 + matOffset;
	double *subMatTemp = subMatTemp0 + matOffset;

	double *EmatOne = Emat + numS*numS*(photon_color - 1);


	for (int i = 0; i < numS*numS; i++)
	{
		subMat[i] = subMatArray[matOffset + i];
	}

	for (int i = 0; i < blockSize - 1; i++)
	{
		cudaMatrixAxB(subMatArray + matOffset + numS*numS*(i + 1), subMat, subMatTemp, numS, numS, numS);
		for (int j = 0; j < numS*numS; j++)
		{
			subMat[j] = subMatTemp[j];
		}
	}

	cudaMatrixAxB(EmatOne, subMat, subMatTemp, numS, numS, numS);
	cudaMatrixAxB(eigenmat, subMatTemp, subMat, numS, numS, numS);
	cudaMatrixAxB(subMat, inveigenmat, subMatTemp, numS, numS, numS);

	cudaMatrixAxB(subMatTemp, peq, subMat, numS, numS, 1); // reuse subMat to save final vector

	for (int i = 1; i < numS; i++) subMat[0] += subMat[i]; // save the sum to subMat[0]
	logpArray[blockSize*blockIdx.x] += log(subMat[0]);
	for (int i = 1; i < blockSize; i++)
	{
		logpArray[blockSize*blockIdx.x] += logpArray[blockSize*blockIdx.x + i];
	}

	//logpArray[blockSize*blockIdx.x] = -logpArray[blockSize*blockIdx.x]; //final value for a molecule, save to an unused area
	subMat0[numS*numS + blockIdx.x] = -logpArray[blockSize*blockIdx.x]; //final value for a molecule, save to an unused area
}

double calcProbeoneCU(mlh_param_pack *m_pack)
{
	c_data *input_data = m_pack->data;
	mlh_vars *m_vars = m_pack->vars;
	/* GPU thread structure */
	mwSize indexone_len = input_data->indexone_len;
	mwSize numOfMol = indexone_len;
	//mexPrintf("indexone_len=%d\n", indexone_len);
	int nDevices = m_vars->nDevices;

	dim3 block = m_vars->block;
	dim3 *grid = m_vars->grid;

	int blockSize = m_vars->blockSize;

	cudaStream_t *streams = m_vars->streams;

	/* Assign data */

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	double **logpArray = m_vars->logpArray;
	double **subMatArray = m_vars->subMatArray;
	double **cumindex = m_vars->cumindex;
	double **indexone = m_vars->indexone;
	double **frburstdata = m_vars->frburstdata;

	double **rateeig = m_vars->rateeig;
	double *h_rateeig = m_vars->h_rateeig;

	double **Emat = m_vars->d_Emat;
	double *h_Emat = m_vars->h_Emat;

	double **d_peq = m_vars->d_peq;
	double *h_peq = m_vars->h_peq;

	double **eigenmat = m_vars->eigenmat;
	double *h_eigenmat = m_vars->h_eigenmat;

	double **inveigenmat = m_vars->inveigenmat;
	double *h_inveigenmat = m_vars->h_inveigenmat;

	double **expRatemat = m_vars->expRatemat;
	double **kXE = m_vars->kXE;
	double **subMat = m_vars->subMat;
	double **subMatTemp = m_vars->subMatTemp;

	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		cudaCheck(cudaStreamCreate(&(streams[i])));

		cudaCheck(cudaMemcpy(rateeig[i], h_rateeig, numOfMol*numS * sizeof*rateeig[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMemcpy(Emat[i], h_Emat, numOfMol*numC*numS*numS * sizeof*Emat[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMemcpy(d_peq[i], h_peq, numOfMol*numS * sizeof*d_peq[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMemcpy(eigenmat[i], h_eigenmat, numOfMol*numS*numS * sizeof*eigenmat[i], cudaMemcpyHostToDevice));
		cudaCheck(cudaMemcpy(inveigenmat[i], h_inveigenmat, numOfMol*numS*numS * sizeof*inveigenmat[i], cudaMemcpyHostToDevice))
	}

	for (int i = 0; i < nDevices; i++)
	{

		cudaCheck(cudaSetDevice(i));
		block.x = blockSize;
		calcProbeoneSubMatrix << <grid[i], block, 0, streams[i] >> >(logpArray[i], subMatArray[i], cumindex[i], indexone[i], frburstdata[i], \
			rateeig[i], Emat[i], d_peq[i], numS, grid[0].x*i, input_data->frburst_len_m, input_data->frburst_len_n, \
			expRatemat[i], kXE[i], subMat[i], subMatTemp[i], numC);
	}

	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		block.x = 1;
		calcProbeone << <grid[i], block, 0, streams[i] >> >(logpArray[i], subMatArray[i], cumindex[i], indexone[i], frburstdata[i], \
			rateeig[i], Emat[i], d_peq[i], numS, grid[0].x*i, input_data->frburst_len_m, input_data->frburst_len_n, \
			eigenmat[i], inveigenmat[i], blockSize, subMat[i], subMatTemp[i], numC);
	}

	double probeone = 0;
	double *proboneT = m_vars->proboneT;

	for (int i = 0; i < nDevices; i++)
	{
		cudaCheck(cudaSetDevice(i));
		cudaCheck(cudaDeviceSynchronize());
		cudaCheck(cudaMemcpy(proboneT, subMat[i] + numS*numS, grid[i].x * sizeof*proboneT, cudaMemcpyDeviceToHost));
		for (int j = 0; j < grid[i].x; j++)
		{
			probeone += proboneT[j];
		}
	}

	return probeone;
}
__device__ void cudaMatrixAxB(double *A, double *B, double *C, const size_t m, const size_t l, const size_t n)
{
	// Multiply A(m by l) X B(l by n)= C(m by n)
	for (size_t i = 0; i<m; i++)
		for (size_t j = 0; j < n; j++)
		{
			C[n*i + j] = 0;
			for (size_t k = 0; k < l; k++)
				C[n*i + j] += A[i*l + k] * B[k*n + j];
		}
}

__device__ double roughNorm(double *A, const size_t m, const size_t n)
{
	// roughly normalize the matrix and return the norm
	double norm = 0;
	double magicN = 1.65; //manual scaling factor
	for (size_t i = 0; i < m; i++)
	{
		for (size_t j = 0; j < n; j++)
		{
			norm += A[n*i + j] * A[n*i + j];
		}
	}
	norm *= powf((m + n) / 2, magicN);

	for (size_t i = 0; i < m; i++)
	{
		for (size_t j = 0; j < n; j++)
		{
			A[n*i + j] /= norm;
		}
	}

	return norm;
}
#endif