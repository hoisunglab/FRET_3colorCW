#include <Windows.h>
#include <process.h>
#include <stdlib.h>

// The following lines must be located BEFORE '#include <mex.h>'
#ifdef _MSC_VER
#define MW_NEEDS_VERSION_H
//#define DLL_EXPORT_SYM __declspec(dllexport)
#else
#define DLL_EXPORT_SYM
#endif

#include <mex.h>
#include <matrix.h>
#include <math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_eigen.h.>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_linalg.h>

const size_t maxThread = 12;
//volatile HANDLE Threads[maxThread];


/* For later use. Maybe?

// mxArray structure of input variables
typedef struct _M_DATA {
	const mxArray *initparams_m, *LUbounds_m, *frburstdata_m, *cumindex_m, *indexone_m;
} m_data;

// convert matlab array to gsl_matrix
void matlab_to_gsl(gsl_matrix *gsl_m,const mxArray *matlab_m)
{
	double * matlab_double=mxGetPr(matlab_m);
	gsl_matrix_view matalb_view=gsl_matrix_view_array(matlab_double,mxGetN(matlab_m),mxGetM(matlab_m));
	gsl_matrix_transpose_memcpy(gsl_m,&matalb_view.matrix);
	return;
}
*/

// C data structure of input variables 
typedef struct _C_DATA {
	double *initparams, *LUbounds, *frburstdata, *cumindex, *indexone, *E, *params, *cntrate, *fixed, *stateid, *exid, *conc;
	
	mwSize number_of_parameters;
	mwSize number_of_fixed;
	mwSize number_of_fittingParams;
	mwSize number_of_states;
	mwSize number_of_colors;
	mwSize cumindex_len;
	mwSize indexone_len;
	mwSize frburst_len_m;
	mwSize frburst_len_n;
	mwSize number_of_evaluations;

	gsl_vector *L_bound;
	gsl_vector *U_bound;
} c_data;


/* variables for mlhratesub. It would be better to make a class... */
typedef struct _MLH_VARS {
gsl_vector *pconv;
gsl_vector **peq;

gsl_matrix **ratemat0;
gsl_eigen_nonsymmv_workspace **W;
gsl_vector_complex **eigen_values;
gsl_matrix_complex **eigen_mat;
gsl_matrix_complex **inv_eigen_mat;

//FRET matrix
gsl_matrix_complex ****Emat;
gsl_matrix_complex ****Emat_diag;

// MLE cursor vector, probone
gsl_vector_complex **probonesub;
gsl_vector_complex **probonesub_t;
//rate matrix variables
gsl_matrix_complex **ratemat;
gsl_matrix_complex **ratemat_x_E;
gsl_vector_complex_view *ratemat_diag_view;
} mlh_vars;

typedef struct _MLH_MT_VARS {
	gsl_vector * param; //minimizer vector
	gsl_vector * param0; //full parameter
	mlh_vars * m_vars;
	unsigned curThread;
	HANDLE ThreadHandle;
	unsigned int threadID;
	c_data *input_data;
	double probeone;
} mt_vars;

typedef struct _MLH_PARAM_PACK {
c_data *data;
mlh_vars *vars;
} mlh_param_pack;

/* Main routines */
bool input_from_matlab( const mxArray *prhs[] ,c_data *input_data); // Initialize input data using MATLAB input
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);
double mlhratesub (const gsl_vector * param, void * c_data); 		// Return MLE for the given parammeter and c_data. The function to be minimized.
gsl_vector *calc_mlh(c_data *input_data); 							// Find maximum-likelihood parameter
gsl_vector *calc_mlh_sub(c_data *input_data);	// for error calc.
bool touchedBoundary(gsl_vector *x, c_data *input_data); //check proximity of the running parameter to the boundary
bool output_to_matlab(gsl_vector *output_data, mxArray *prls[]);		// Relay the parameter to MATLAB

/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);	//dynamics allocation of mlh_vars
bool free_mlh_vars(mlh_vars *var, const c_data *input_data);

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 		//convert unbound param to bound pconv
int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 	//convert bound param to unbound pconv

/* GSL utililties */
int gsl_linalg_inv (const gsl_matrix_complex * A,gsl_matrix_complex *  inv_A); //calculate inverse matrix of A using LU decomposition
gsl_complex gsl_r2c(double r);	//convert real variable r to complex variable r+0i
double gsl_vector_complex_norm(gsl_vector_complex *v);	//calculate norm of vector v
double gsl_vector_complex_sum(gsl_vector_complex *v);	//summate absolute value of each element of v

/* Destructor */
bool input_data_free(c_data * input_data);	// free input_data

// CPU MT
unsigned __stdcall analysisThread(void *param);

bool input_from_matlab(const mxArray *prhs[], c_data *input_data)
// Initialize input data using MATLAB input
{
	input_data->initparams = mxGetPr(prhs[0]);
	input_data->LUbounds = mxGetPr(prhs[1]);
	input_data->frburstdata = mxGetPr(prhs[2]);
	input_data->cumindex = mxGetPr(prhs[3]);
	input_data->indexone = mxGetPr(prhs[4]);
	input_data->cntrate = mxGetPr(prhs[5]);
	input_data->fixed = mxGetPr(prhs[6]);
	input_data->stateid = mxGetPr(prhs[7]);
	input_data->exid = mxGetPr(prhs[8]);
	input_data->conc= mxGetPr(prhs[9]);

	input_data->number_of_parameters = mxGetM(prhs[0]);
	input_data->number_of_evaluations = mxGetN(prhs[0]);

	/* Customization starts */

	input_data->number_of_states = (input_data->number_of_parameters-9)/7;
	input_data->number_of_states *= 4;//with acceptor blinking modes of A1 and A2
	input_data->number_of_fixed = 0;
	for (int i = 0; i < input_data->number_of_parameters;i++)
	{
		if (input_data->fixed[i]>0) input_data->number_of_fixed++;
	}

	input_data->number_of_fittingParams = input_data->number_of_parameters - input_data->number_of_fixed;
	input_data->number_of_colors = 3;
	/* Customization ends*/

	input_data->cumindex_len = mxGetNumberOfElements(prhs[3]);
	input_data->indexone_len = mxGetNumberOfElements(prhs[4]);
	input_data->frburst_len_m = mxGetM(prhs[2]);
	input_data->frburst_len_n = mxGetN(prhs[2]);

	input_data->L_bound = gsl_vector_calloc(input_data->number_of_parameters);
	input_data->U_bound = gsl_vector_calloc(input_data->number_of_parameters);

	for (mwSize i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(input_data->L_bound, i, input_data->LUbounds[i]);
		gsl_vector_set(input_data->U_bound, i, input_data->LUbounds[input_data->number_of_parameters + i]);
	}

	/* Consistency check */
	// number_of_parameters should be consistent
	if (mxGetM(prhs[1]) != input_data->number_of_parameters)
	{
		mexPrintf("numel(LUbound)=%d, numOfParam=%d\n", mxGetM(prhs[1]), input_data->number_of_parameters);
		return true;
	}
	// A parameter should be between its LU bound

	for (size_t i = 0; i < input_data->number_of_parameters; i++)
	{
		if (input_data->initparams[i] < input_data->LUbounds[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->initparams[i], input_data->LUbounds[i]);
			return true;
		}
		if (input_data->LUbounds[input_data->number_of_parameters + i] < input_data->initparams[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->LUbounds[input_data->number_of_parameters + i], input_data->initparams[i]);
			return true;
		}

	}

	return false;
}

double mlhratesub(const gsl_vector * param, void * input_pack) //for 3-color segments
// Return MLE for the given parammeter and c_data. The function to be minimized.
{
	mt_vars *mt_param = (mt_vars *)input_pack;
	c_data *input_data = mt_param[0].input_data;
	
	for (int i = 0; i < maxThread; i++)
	{
		int ii = 0;
		for (int j = 0; j < input_data->number_of_parameters; j++)
		{
			if (input_data->fixed[j] == 0) // change nonfixed params
			{
				gsl_vector_set(mt_param[i].param0, j, gsl_vector_get(param, ii));
				ii++;
			}
			//gsl_vector_memcpy(mt_param[i].param, param);
		}
		
		mt_param[i].curThread = i;
		mt_param[i].ThreadHandle = (HANDLE)_beginthreadex(NULL, 0, &analysisThread, (void *)&mt_param[i], 0, &mt_param[i].threadID);
	}
	for (int i = 0; i < maxThread; i++)
	{
		WaitForSingleObject(mt_param[i].ThreadHandle, INFINITE);
	}

	for (int i = 1; i < maxThread; i++) mt_param[0].probeone += mt_param[i].probeone; //sum up probeone of each thread
	return mt_param[0].probeone;
}



gsl_vector *calc_mlh(c_data *input_data)
// Find maximum-likelihood parameter
{
	const gsl_multimin_fminimizer_type *T =
		//gsl_multimin_fminimizer_nmsimplex2rand;//gsl_multimin_fminimizer_nmsimplex2
	gsl_multimin_fminimizer_nmsimplex2;//gsl_multimin_fminimizer_nmsimplex2
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x, *xTemp, *init_param, *output_param;
	gsl_multimin_function minex_func;

	size_t iter = 0;
	int status;
	double size;
	
	mt_vars mt_param[maxThread];

	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_fittingParams);
		mt_param[i].param0 = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}

	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	xTemp = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_parameters);

	/* Starting point */
	x = gsl_vector_calloc(input_data->number_of_fittingParams);

	for (size_t i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(init_param, i, input_data->initparams[i]);
	}
	LUbound_invconv(init_param, input_data, xTemp);

	int ii = 0;
	for (int i = 0; i < input_data->number_of_parameters; i++)
	{
		for (int j = 0; j < maxThread; j++)
		{
			gsl_vector_set(mt_param[j].param0, i, gsl_vector_get(xTemp, i));
		}

		if (input_data->fixed[i] == 0)
		{
			gsl_vector_set(x, ii, gsl_vector_get(xTemp, i));
			ii++;
		}
	}

	/* Set initial step sizes to 1 */
	ss = gsl_vector_calloc(input_data->number_of_fittingParams);
	gsl_vector_set_all(ss, 1);

	/* Initialize method and iterate */
	minex_func.n = input_data->number_of_fittingParams;
	minex_func.f = &mlhratesub;
	minex_func.params = mt_param;

	s = gsl_multimin_fminimizer_alloc(T, input_data->number_of_fittingParams);
	gsl_multimin_fminimizer_set(s, &minex_func, x, ss);

	do
	{
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		if (status)
			break;

		size = gsl_multimin_fminimizer_size(s);
		status = gsl_multimin_test_size(size, 1e-3);
		//status = gsl_multimin_test_size (size, 1e-4);

		/*
		if (status == GSL_SUCCESS)
		{
		mexPrintf ("converged to minimum at\n");
		}
		mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
		iter,
		gsl_vector_get (s->x, 0),
		gsl_vector_get (s->x, 1),
		gsl_vector_get (s->x, 2),
		gsl_vector_get (s->x, 3),
		s->fval, size);
		*/

		if ((iter + 1) % 50 == 0) {
			int iParam = 0;
			for (int i = 0; i < input_data->number_of_parameters; i++)
			{
				if (input_data->fixed[i] == 0) //is not fixed
				{
					gsl_vector_set(xTemp, i, gsl_vector_get(s->x, iParam));
					iParam++;
				}
			}
			LUbound_conv(xTemp, input_data, output_param);

			if (touchedBoundary(output_param, input_data)) {
				mexPrintf("Warning: touched the boundary, iter=%d\nthe minimizer terminated before converge\n",iter);
				break;
			}
		}
	} while (status == GSL_CONTINUE && iter < 3000);

	if (iter == 3000)
	{
		mexPrintf("Warning: 3000 interations, the minimizer terminated before converge\n");
	}
	/*	  mexPrintf ("%5d %10.3e %10.3e %10.3e %10.3e f() = %7.3f size = %.3f\n",
	iter,
	gsl_vector_get (s->x, 0),
	gsl_vector_get (s->x, 1),
	gsl_vector_get (s->x, 2),
	gsl_vector_get (s->x, 3),
	s->fval, size);
	*/
	ii = 0;
	for (int i = 0; i < input_data->number_of_parameters; i++)
	{
		if (input_data->fixed[i] == 0) //is not fixed
		{
			gsl_vector_set(xTemp, i, gsl_vector_get(s->x, ii));
			ii++;
		}
	}
	LUbound_conv(xTemp, input_data, output_param);

	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s);
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		gsl_vector_free(mt_param[i].param0);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
	gsl_vector_free(init_param);
	gsl_vector_free(xTemp);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

bool touchedBoundary(gsl_vector *x, c_data *input_data)
{
	double L_bound_value = 0;
	double U_bound_value = 0;
	double paramValue = 0;
	double L_proximity = 1;
	double U_proximity = 1;

	double proximity_criteria = 1e-2;

	for (int iParam = 0; iParam < input_data->number_of_parameters; iParam++) {
		if (input_data->fixed[iParam] != 0) continue; //if fixed, continue

		L_bound_value = gsl_vector_get(input_data->L_bound, iParam);
		U_bound_value = gsl_vector_get(input_data->U_bound, iParam);
		paramValue = gsl_vector_get(x, iParam);

		L_proximity = (paramValue - L_bound_value)/ (U_bound_value - L_bound_value);
		U_proximity = (U_bound_value - paramValue) / (U_bound_value - L_bound_value);

		//if (paramValue<L_bound_value || paramValue>U_bound_value) return true;
		if (L_proximity < proximity_criteria || U_proximity < proximity_criteria) {
			printf("%dth param: L=%f, param=%f, U=%f\n", iParam+1, L_bound_value, paramValue, U_bound_value);
			return true;
		}
	}
	return false;
}

gsl_vector *calc_mlh_sub(c_data *input_data)
// Return logmlh values
{
	gsl_vector *x, *init_param, *output_param;
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	x = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_evaluations);
	
	//mlh_vars *m_vars = new mlh_vars;
	//mlh_param_pack *m_pack = new mlh_param_pack;
	//m_pack->data = input_data;
	//m_pack->vars = m_vars;
	//init_mlh_vars(m_vars, input_data);

	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].param0 = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;

		init_mlh_vars(mt_param[i].m_vars, input_data);
	}

	void * input_pack = mt_param;

	for (size_t i = 0; i<input_data->number_of_evaluations; i++)
	{
		for (size_t j = 0; j<input_data->number_of_parameters; j++) // interation on initparams
		{
			gsl_vector_set(init_param, j, input_data->initparams[i*input_data->number_of_parameters + j]);
			//mexPrintf("%f\t", input_data->initparams[i*input_data->number_of_parameters + j]);
		}
		//mexPrintf("\n");
		gsl_vector_memcpy(x, init_param);
		gsl_vector_set(output_param, i, mlhratesub(x, input_pack)); //save mlhratesub value to output_param
	}
	//free_mlh_vars(m_vars, input_data);
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		gsl_vector_free(mt_param[i].param0);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
	gsl_vector_free(init_param);
	gsl_vector_free(x);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

bool output_to_matlab(gsl_vector *output_data, mxArray *plhs[])
// Relay the output parameter to MATLAB
{
	plhs[0] = mxCreateDoubleMatrix(output_data->size, 1, mxREAL);
	double * output = mxGetPr(plhs[0]);
	for (mwSize i = 0; i<output_data->size; i++)
	{
		output[i] = gsl_vector_get(output_data, i);
	}

	return true;
}


/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data)
//pre-allocate dynamic variables that repeatedly used in calc_mlh
{
	const mwSize numC = input_data->number_of_colors;
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;

	mwSize numSState = 3;
	mwSize numEx = 2;
	//pconv is a converted parameter from by appling LUbound

	/*
	var->pconv = gsl_vector_calloc(numP);
	var->peq = gsl_vector_calloc(numS);

	var->ratemat0 = gsl_matrix_calloc(numS, numS);
	var->W = gsl_eigen_nonsymmv_alloc(numS);
	var->eigen_values = gsl_vector_complex_calloc(numS);
	var->eigen_mat = gsl_matrix_complex_calloc(numS, numS);
	var->inv_eigen_mat = gsl_matrix_complex_calloc(numS, numS);

	// MLE cursor vector, probone
	var->probonesub = gsl_vector_complex_calloc(numS);
	var->probonesub_t = gsl_vector_complex_calloc(numS);

	//rate matrix variables
	var->ratemat = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_x_E = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_diag_view = gsl_matrix_complex_diagonal(var->ratemat);
	*/

	var->pconv = gsl_vector_calloc(numP);
	var->peq = new gsl_vector*[numSState];

	var->ratemat0 = new gsl_matrix*[numSState];
	var->W = new gsl_eigen_nonsymmv_workspace*[numSState];
	var->eigen_values = new gsl_vector_complex*[numSState];
	var->eigen_mat = new gsl_matrix_complex*[numSState];
	var->inv_eigen_mat = new gsl_matrix_complex*[numSState];

	var->probonesub = new gsl_vector_complex*[numSState];
	var->probonesub_t = new gsl_vector_complex*[numSState];

	//rate matrix variables
	var->ratemat = new gsl_matrix_complex*[numSState];
	var->ratemat_x_E = new gsl_matrix_complex*[numSState];
	var->ratemat_diag_view = new gsl_vector_complex_view[numSState];
	
	//FRET matrix
	var->Emat = new gsl_matrix_complex***[numSState];
	var->Emat_diag = new gsl_matrix_complex***[numSState];

	for (mwSize i = 0; i<3; i++) // DA1A2
	{
		var->peq[i] = gsl_vector_calloc(numS);

		var->ratemat0[i] = gsl_matrix_calloc(numS, numS);
		var->W[i] = gsl_eigen_nonsymmv_alloc(numS);
		var->eigen_values[i] = gsl_vector_complex_calloc(numS);
		var->eigen_mat[i] = gsl_matrix_complex_calloc(numS, numS);
		var->inv_eigen_mat[i] = gsl_matrix_complex_calloc(numS, numS);

		var->probonesub[i] = gsl_vector_complex_calloc(numS);
		var->probonesub_t[i] = gsl_vector_complex_calloc(numS);

		//rate matrix variables
		var->ratemat[i] = gsl_matrix_complex_calloc(numS, numS);
		var->ratemat_x_E[i] = gsl_matrix_complex_calloc(numS, numS);
		var->ratemat_diag_view[i] = gsl_matrix_complex_diagonal(var->ratemat[i]);

		var->Emat[i] = new gsl_matrix_complex**[numEx];
		var->Emat_diag[i] = new gsl_matrix_complex**[numEx];

		for (mwSize j = 0; j < numEx; j++)
		{
			var->Emat[i][j]= new gsl_matrix_complex*[numC];
			var->Emat_diag[i][j] = new gsl_matrix_complex*[numC];
			for (mwSize k = 0; k < numC; k++)
			{
				var->Emat[i][j][k] = gsl_matrix_complex_calloc(numS, numS);
				var->Emat_diag[i][j][k] = gsl_matrix_complex_calloc(numS, numS);
			}
		}
	}

	/*
	size_t numS2 = numS / 2;
	for (mwSize i = 1; i<3; i++) // DA1, DA2 have numS/2 states
	{
		var->peq[i] = gsl_vector_calloc(numS2);

		var->ratemat0[i] = gsl_matrix_calloc(numS2, numS2);
		var->W[i] = gsl_eigen_nonsymmv_alloc(numS2);
		var->eigen_values[i] = gsl_vector_complex_calloc(numS2);
		var->eigen_mat[i] = gsl_matrix_complex_calloc(numS2, numS2);
		var->inv_eigen_mat[i] = gsl_matrix_complex_calloc(numS2, numS2);

		var->probonesub[i] = gsl_vector_complex_calloc(numS2);
		var->probonesub_t[i] = gsl_vector_complex_calloc(numS2);

		//rate matrix variables
		var->ratemat[i] = gsl_matrix_complex_calloc(numS2, numS2);
		var->ratemat_x_E[i] = gsl_matrix_complex_calloc(numS2, numS2);
		var->ratemat_diag_view[i] = gsl_matrix_complex_diagonal(var->ratemat[i]);

		var->Emat[i] = new gsl_matrix_complex**[numEx];
		var->Emat_diag[i] = new gsl_matrix_complex**[numEx];

		for (mwSize j = 0; j < numEx; j++)
		{
			var->Emat[i][j] = new gsl_matrix_complex*[numC];
			var->Emat_diag[i][j] = new gsl_matrix_complex*[numC];
			for (mwSize k = 0; k < numC; k++)
			{
				var->Emat[i][j][k] = gsl_matrix_complex_calloc(numS2, numS2);
				var->Emat_diag[i][j][k] = gsl_matrix_complex_calloc(numS2, numS2);
			}
		}
	}*/

	return false;
}

bool free_mlh_vars(mlh_vars *var, const c_data *input_data)
{
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;
	const mwSize numC = input_data->number_of_colors;

	//FRET matrix
	mwSize numSState = 3;
	mwSize numEx = 2;

	gsl_vector_free(var->pconv);

	for (mwSize i = 0; i<numSState; i++) // 0: acceptor, 1: donor
	{
		gsl_vector_free(var->peq[i]);

		gsl_matrix_free(var->ratemat0[i]);
		gsl_eigen_nonsymmv_free(var->W[i]);
		gsl_vector_complex_free(var->eigen_values[i]);
		gsl_matrix_complex_free(var->eigen_mat[i]);
		gsl_matrix_complex_free(var->inv_eigen_mat[i]);

		// MLE cursor vector, probone
		gsl_vector_complex_free(var->probonesub[i]);
		gsl_vector_complex_free(var->probonesub_t[i]);

		//rate matrix variables
		gsl_matrix_complex_free(var->ratemat[i]);
		gsl_matrix_complex_free(var->ratemat_x_E[i]);

		for (mwSize j = 0; j < numEx; j++)
		{
			for (mwSize k = 0; k < numC; k++)
			{
				gsl_matrix_complex_free(var->Emat[i][j][k]);
				gsl_matrix_complex_free(var->Emat_diag[i][j][k]);
			}
			delete(var->Emat[i][j]);
			delete(var->Emat_diag[i][j]);
		}
		delete(var->Emat[i]);
		delete(var->Emat_diag[i]);
	}

	delete(var->Emat);
	delete(var->Emat_diag);
	delete(var->peq);

	delete(var->ratemat0);
	delete(var->W);
	delete(var->eigen_values);
	delete(var->eigen_mat);
	delete(var->inv_eigen_mat);

	// MLE cursor vector, probone
	delete(var->probonesub);
	delete(var->probonesub_t);

	//rate matrix variables
	delete(var->ratemat);
	delete(var->ratemat_x_E);
	delete(var->ratemat_diag_view);

	return false;
}


int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert unbound param to bound pconv
{
	//convert using atan function
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param); //temp=param
	
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, atan(gsl_vector_get(temp, i))); //pconv=atan(param)
	}

	gsl_vector_add_constant(pconv, 0.5*M_PI); //pconv=atan(param)+0.5*pi
	
	gsl_vector_memcpy(temp, input_data->U_bound);
	gsl_vector_sub(temp, input_data->L_bound); //temp=U-L
	gsl_vector_scale(temp, 1 / M_PI); //temp=(U-L)/pi

	gsl_vector_mul(pconv, temp); //pconv=(atan(param)+0.5*pi)*(U-L)/pi
	gsl_vector_add(pconv, input_data->L_bound); //pconv=(atan(param)+0.5*pi)*(U-L)/pi+L
	
	gsl_vector_free(temp);
	return 0;

	/*
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);

	gsl_vector_mul(temp, param); //temp=param^2
	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound); //pconv=U-L
	gsl_vector_add_constant(temp, 1.0);//temp=1+param^2;
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(1+param^2);
	gsl_vector_add(pconv, input_data->L_bound);//pconv=(U-L)/(1+param^2)+L;

	gsl_vector_free(temp);
	return 0;
	*/
}

int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert bound param to unbound pconv
{
	//convert using tangent function
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);
	gsl_vector_sub(temp, input_data->L_bound);//temp=param-L

	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound);//pconv=U-L
	gsl_vector_div(temp, pconv);//temp=(param-L)/(U-L)
	gsl_vector_scale(temp, M_PI); //temp = pi*(param - L) / (U - L)
	gsl_vector_add_constant(temp,-0.5*M_PI);
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, tan(gsl_vector_get(temp, i)));
	}
	gsl_vector_free(temp);
	return 0;
	/*
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);
	gsl_vector_sub(temp, input_data->L_bound);//temp=param-L

	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound);//pconv=U-L
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(param-L);
	gsl_vector_add_constant(pconv, -1);//pconv=(U-L)/(param-L)-1
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, sqrt(gsl_vector_get(pconv, i)));
	}
	gsl_vector_free(temp);
	return 0;
	*/
}

/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A)
//calculate inverse matrix of A using LU decomposition
{
	gsl_matrix_complex *A_copy = gsl_matrix_complex_calloc(A->size1, A->size2);
	gsl_matrix_complex_memcpy(A_copy, A);
	gsl_permutation *p = gsl_permutation_calloc(A->size1);
	int signum = 0;
	gsl_linalg_complex_LU_decomp(A_copy, p, &signum);
	gsl_linalg_complex_LU_invert(A_copy, p, inv_A);

	gsl_matrix_complex_free(A_copy);
	gsl_permutation_free(p);
	return 0;
}

gsl_complex gsl_r2c(double r)
//convert real variable r to complex variable r+0i
{
	gsl_complex c;
	GSL_SET_COMPLEX(&c, r, 0);
	return c;
}


double gsl_vector_complex_norm(gsl_vector_complex *v)
//calculate norm of vector v
{
	double norm_square = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		norm_square += gsl_complex_abs2(gsl_vector_complex_get(v, i));
	}
	return sqrt(norm_square);
}

double gsl_vector_complex_sum(gsl_vector_complex *v)
//summate absolute value of all element of v
{
	double sum = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		sum += gsl_complex_abs(gsl_vector_complex_get(v, i));
	}
	return sum;
}

void gsl_matrix_add_element(gsl_matrix *m, size_t i, size_t j, double x)
//add x to (i,j)
{
	gsl_matrix_set(m, i, j, gsl_matrix_get(m, i, j) + x);
}

int gsl_blas_mm(gsl_matrix *m1, gsl_matrix *m2, gsl_matrix *m1m2, int n)
{
	gsl_matrix_set_zero(m1m2);

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			for (int k = 0; k < n; k++)
			{
				gsl_matrix_add_element(m1m2, i, j, gsl_matrix_get(m1, i, k)*gsl_matrix_get(m2, k, j));
			}
		}
	}
	return 0;
}
/* Destructor */

bool input_data_free(c_data * input_data)
// free input_data
{
	gsl_vector_free(input_data->L_bound);
	gsl_vector_free(input_data->U_bound);
	delete(input_data);
	return false;
}