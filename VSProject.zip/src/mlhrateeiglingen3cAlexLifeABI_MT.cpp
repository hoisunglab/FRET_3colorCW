
#include "mlhrateeiglingen3cAlexLifeABI_MT.h"


/*
For 3-color ALEX.
See mlhrateeiglingen3cAlexABIC.m for input parameters.

Photon color	1=Acceptor 2
				2=Acceptor 1
				3=Donor

State id		1=DA1A2
				2=DA1
				3=DA2

Excitation id	1=Donor
				2=Acceptor
*/

/* Customization starts */
bool ratemat2st_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}
/* Customization ends */

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const double *pF, const double *pB, const double *ratesumn, const double *ratesumB, const mwSize numSb, const mwSize numAcc, const double conc)
// initialize the ratematrix using p_eq and ratesum
{
	double kB[2];
	double kD[2];

	for (mwSize i = 0; i < numAcc; i++) {
		kB[i] = ratesumB[i] * pB[i];
		kD[i] = ratesumB[i] * (1 - pB[i]);
	}

	gsl_matrix_set_zero(ratemat0);
	for (mwSize i = 0; i < numSb - 1; i++) {
		gsl_matrix *ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector *peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, pF[i]);
		gsl_vector_set(peqtemp, 1, pF[i + 1] * conc);
		gsl_vector_scale(peqtemp, 1 / (pF[i] + pF[i + 1] * conc));
		ratemat2st_init(ratemattemp, peqtemp, ratesumn[i] * (pF[i] + pF[i + 1] * conc) / (pF[i] + pF[i + 1]));

		for (mwSize j = 0; j < 4; j++) {
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j) + gsl_matrix_get(ratemattemp, 0, 0));
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 0, 1));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j) + gsl_matrix_get(ratemattemp, 1, 0));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 1, 1));
		}
		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}
	for (mwSize i = 0; i < 2 * numSb; i++) {
		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) - kD[0]);
		gsl_matrix_set(ratemat0, i + 2 * numSb, i, gsl_matrix_get(ratemat0, i + 2 * numSb, i) + kD[0]);
		gsl_matrix_set(ratemat0, i, i + 2 * numSb, gsl_matrix_get(ratemat0, i, i + 2 * numSb) + kB[0]);
		gsl_matrix_set(ratemat0, i + 2 * numSb, i + 2 * numSb, gsl_matrix_get(ratemat0, i + 2 * numSb, i + 2 * numSb) - kB[0]);
	}
	for (mwSize i = 0; i < numSb; i++) {
		for (mwSize j = 0; j < 2; j++) {
			gsl_matrix_set(ratemat0, i + 2 * numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + 2 * numSb*j) - kD[1]);
			gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j) + kD[1]);
			gsl_matrix_set(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j) + kB[1]);
			gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j) - kB[1]);
		}
	}
	/* Customization ends */

	return false;
}

/* Customization starts */
bool ratemat0_init2(gsl_matrix *ratemat0, const double *pF, const double pB, const double *ratesumn, const double ratesumB, const mwSize numSb, const mwSize numAcc, const double conc)
// initialize the ratematrix using p_eq and ratesum for DA1 and DA2
{
	double kB;
	double kD;

	kB = ratesumB * pB;
	kD = ratesumB * (1 - pB);

	gsl_matrix_set_zero(ratemat0);
	for (mwSize i = 0; i < numSb - 1; i++) {
		gsl_matrix *ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector *peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, pF[i]);
		gsl_vector_set(peqtemp, 1, pF[i + 1] * conc);

		gsl_vector_scale(peqtemp, 1 / (pF[i] + pF[i + 1] * conc));
		ratemat2st_init(ratemattemp, peqtemp, ratesumn[i] * (pF[i] + pF[i + 1] * conc) / (pF[i] + pF[i + 1]));

		for (mwSize j = 0; j < 2; j++) {
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j) + gsl_matrix_get(ratemattemp, 0, 0));
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 0, 1));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j) + gsl_matrix_get(ratemattemp, 1, 0));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 1, 1));
		}
		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}

	for (mwSize i = 0; i < numSb; i++) {
		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) - kD);
		gsl_matrix_set(ratemat0, i + numSb, i, gsl_matrix_get(ratemat0, i + numSb, i) + kD);
		gsl_matrix_set(ratemat0, i, i + numSb, gsl_matrix_get(ratemat0, i, i + numSb) + kB);
		gsl_matrix_set(ratemat0, i + numSb, i + numSb, gsl_matrix_get(ratemat0, i + numSb, i + numSb) - kB);
	}
	/* Customization ends */

	return false;
}

/* The gateway function */
DLL_EXPORT_SYM
void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch(nrhs) 
	{
		case 11: //
		{
			//MATLAB variables
			c_data *input_data=new c_data;
			if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
			{
				mexErrMsgTxt("Error: input parameters are inconsistent!");
				return;
			}

			gsl_vector * output_data;
			if (input_data->number_of_evaluations > 1)
			{
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else
			{
				output_data = calc_mlh(input_data);
				output_to_matlab(output_data, plhs);
			}

			//free variables
			input_data_free(input_data);
			gsl_vector_free(output_data);
		}break;

		default:
		{
			mexErrMsgTxt("Error: number of input args should be 11!");
		}
	}
	return;
}

/* Main routines */

unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	mwSize numAcc = 2;	// Number of acceptor (We may try 4-color later)
	mwSize numSb = numS / 4;
	mwSize numEx = 2; //ALEX
	mwSize numSState = 3; //Segment states, DA1A2, DA1, DA2

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//gsl_vector_calloc(param->size);
									  //acquire real parameter pconv from param
	if (input_data->number_of_evaluations == 1)
	{
		LUbound_conv(mt_param->param0, input_data, pconv);
		//gsl_vector_memcpy(pconv, mt_param->param0);
	}
	else
	{
		gsl_vector_memcpy(pconv, mt_param->param0);
	}

	/* Customization starts */
	auto A1 = new double**[numEx];
	auto tau1 = new double**[numEx];
	auto tau2 = new double**[numEx];

	//double* t0 = input_data->t0;
	double t0[2]{ gsl_vector_get(pconv, 71),gsl_vector_get(pconv, 72) };
	double tA2[2]{ gsl_vector_get(pconv, 69),gsl_vector_get(pconv, 70) };
	double t0_A2{ gsl_vector_get(pconv, 68) };

	double bkg_A2{ gsl_vector_get(pconv, 65) };
	double irfp_A2{ gsl_vector_get(pconv, 66) };
	double irfc_A2{ gsl_vector_get(pconv, 67) };
	double* irfp = input_data->irfp;
	double* irfc = input_data->irfc;
	double* bkg = input_data->bkg;
	auto numLife = input_data->numLife;


	for (auto iEx = 0; iEx < numEx; iEx++)
	{
		A1[iEx] = new double*[numSState+1];
		tau1[iEx] = new double*[numSState+1];
		tau2[iEx] = new double*[numSState+1];
		for (auto iState = 0; iState<numSState + 1; iState++)
		{
			A1[iEx][iState] = new double[numSb];
			tau1[iEx][iState] = new double[numSb];
			tau2[iEx][iState] = new double[numSb];
			for (auto iSb = 0; iSb < numSb; iSb++)
			{
				A1[iEx][iState][iSb] = gsl_vector_get(pconv, 7 * numSb + 9 + 3 * iSb + 6 * iState + 24 * iEx);
				tau1[iEx][iState][iSb] = gsl_vector_get(pconv, 7 * numSb + 10 + 3 * iSb + 6 * iState + 24 * iEx);
				tau2[iEx][iState][iSb] = gsl_vector_get(pconv, 7 * numSb + 11 + 3 * iSb + 6 * iState + 24 * iEx);
			}
		}
	}



	double *eff1s1 = new double[numSb];      // 3-color apparent E1
	double *eff2s1 = new double[numSb];      // 3-color apparent E2
	double *eff12s1 = new double[numSb];      // 2-color A1A2 FRET
	double *effs2 = new double[numSb];      // Apparent E1 for DA1 part (= (A1+A2)/(D+A1+A2))
	double *effs3 = new double[numSb];      // Apparent E2 for DA2 part (= A2/(D+A1+A2))
	double *ratesumn = new double[numSb];
	double *frn = new double[numSb];
	double frnprod = 1;
	double E12D = 1;
	double A2gamma= 1;

	double effD1 = gsl_vector_get(pconv, 5* numSb+1); // E1 of A1,A2 dark state (= A1/(A2 + A1 + D)), D-only
	double effD2 = gsl_vector_get(pconv, 5 * numSb+2); // E2 of A1,A2 dark state (= A2/(A2 + A1 + D)) (depends on the A2-protein concentration)
	double effD12 = gsl_vector_get(pconv, 3 * numSb);       // E12 with no A2: A1 leak into A2 channel
	double kB[2]; //ktobrt, kB[0]: A1, kB[1]: A2
	double pB0[2]; // pB0=kb/(kb+kd0), pB0[0]: A1, pB0[1]: A2

	for (mwSize i = 0; i < numSb; i++) {
		eff1s1[i] = gsl_vector_get(pconv, i);
		eff2s1[i] = gsl_vector_get(pconv, numSb + i);
		effs2[i] = gsl_vector_get(pconv, 2 * numSb + i);
		effs3[i] = gsl_vector_get(pconv, 3 * numSb + i + 1);
		eff12s1[i] = gsl_vector_get(pconv, 4 * numSb + i + 1);
	}
	E12D = gsl_vector_get(pconv, 5 * numSb + 3);
	A2gamma = gsl_vector_get(pconv, 5 * numSb + 4);

	for (mwSize i = 0; i < numSb - 1; i++) {
		ratesumn[i] = gsl_vector_get(pconv, 5 * numSb + i + 5);
		frn[i] = gsl_vector_get(pconv, 6 * numSb + 4 + i);
	}

	for (mwSize i = 0; i < 2; i++) {
		kB[i] = gsl_vector_get(pconv, 7 * numSb + 3 + 2*i);
		pB0[i] = gsl_vector_get(pconv, 7 * numSb + 4 + 2*i);
	}

	double effdA1bgEx2= gsl_vector_get(pconv, 7 * numSb + 7);
	double effdA2bgEx2= gsl_vector_get(pconv, 7 * numSb + 8);

	double *pF = new double[numSb]; //initialize peq in the bright state
	for (mwSize i = 0; i < numSb - 1; i++) {
		pF[i] = frn[i] * frnprod;
		frnprod *= 1 - frn[i];
	}
	pF[numSb - 1] = frnprod;
	/* Customization ends */

	/* Get variables from m_vars */
	gsl_vector **peq = m_vars->peq;
	gsl_matrix **ratemat0 = m_vars->ratemat0;

	// Get diagonalization workspace
	gsl_eigen_nonsymmv_workspace **W = m_vars->W;
	gsl_vector_complex **eigen_values = m_vars->eigen_values;
	gsl_matrix_complex **eigen_mat = m_vars->eigen_mat;
	gsl_matrix_complex **inv_eigen_mat = m_vars->inv_eigen_mat;

	// MLE cursor vector, probone
	gsl_vector_complex **probonesub = m_vars->probonesub;//gsl_vector_complex_calloc(numS);
	gsl_vector_complex **probonesub_t = m_vars->probonesub_t;//gsl_vector_complex_calloc(numS);

	// Get the allocated FRET matrices
	gsl_matrix_complex ****Emat = m_vars->Emat;
	gsl_matrix_complex ****Emat_diag = m_vars->Emat_diag;


	//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	double *cntrate = input_data->cntrate;
	double *stateid = input_data->stateid;
	double *exid = input_data->exid;
	double *conc = input_data->conc;

	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex **ratemat = m_vars->ratemat;//gsl_matrix_complex_calloc(numS,numS);
	gsl_matrix_complex **ratemat_x_E = m_vars->ratemat_x_E;//gsl_matrix_complex_calloc(numS,numS);
	gsl_vector_complex_view *ratemat_diag_view = m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	mt_param->probeone = 0;
	//double ratesumB = 1000;
	/* customization start */
	double ratesumB[2] = { 1000, 1000 };
	double pB[2] = { 1, 1 };
	double kD[2] = { 1000, 1000 };
	/* customization end */

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;
	mwSize delay_time = 1;

	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{
		mwSize curSState = mwSize(stateid[k]) - 1;

		//printf("k=%d,curSState=%d\n",k,curSState);

		/* Customization starts */
		for (mwSize i = 0; i < numAcc; i++) {
			kD[i] = kB[i] * (1 - pB0[i]) / pB0[i] * cntrate[k] / 100; // for 100 photons per ms countrate unit.
			ratesumB[i] = kB[i] + kD[i];
			pB[i] = kB[i] / ratesumB[i];
		}
		//initialize peq
		gsl_vector_set_zero(peq[curSState]);

		for (mwSize i = 0; i < numSb; i++) { 
			//DA1A2
			gsl_vector_set(peq[0], i, pF[i] * pB[0] * pB[1]);
			gsl_vector_set(peq[0], numSb + i, pF[i] * pB[0] * (1 - pB[1]));
			gsl_vector_set(peq[0], 2 * numSb + i, pF[i] * (1 - pB[0]) * pB[1]);
			gsl_vector_set(peq[0], 3 * numSb + i, pF[i] * (1 - pB[0]) * (1 - pB[1]));

			//DA1
			gsl_vector_set(peq[1], i, pF[i] *pB[0]);
			gsl_vector_set(peq[1], numSb + i, pF[i] * (1 - pB[0]));

			//DA2
			gsl_vector_set(peq[2], i, pF[i] *pB[1]);
			gsl_vector_set(peq[2], numSb + i, pF[i] * (1 - pB[1]));
		}
		if (curSState == 0)
		{
			ratemat0_init(ratemat0[0], pF, pB, ratesumn, ratesumB, numSb, numAcc, conc[k]);
		}
		else
		{
			ratemat0_init2(ratemat0[curSState], pF, pB[curSState-1], ratesumn, ratesumB[curSState-1], numSb, numAcc, conc[k]);
		}

		/* Customization ends */
		//initialize peq

		//Do diagonalization
		gsl_eigen_nonsymmv(ratemat0[curSState], eigen_values[curSState], eigen_mat[curSState], W[curSState]); // get eigen values and eigen vector matrix
		gsl_linalg_inv(eigen_mat[curSState], inv_eigen_mat[curSState]); // get inverse of the eigen vector matrix

		// Set FRET matrix
		for (mwSize i = 0; i < numC; i++)
			for (mwSize j = 0; j < numEx; j++)
			{
				gsl_matrix_complex_set_zero(Emat[curSState][j][i]);
				gsl_matrix_complex_set_zero(Emat_diag[curSState][j][i]);
			}

		/* Customization starts */

		const double bgRate = 0.0; //background signal normalized by active fluorescence level.

		gsl_matrix_complex ****pmat_diag = m_vars->pmat_diag;;
		gsl_matrix_complex ****pmat = m_vars->pmat;

		double pLifeSum[2][4]{};
		double pLifeSum2[2][4]{};
		double pLifeSumA2[2]{};
		double pLifeOne = 0;
		double pLifeTwo = 0;

		for (auto iLife = 0; iLife < numLife; iLife++) {
			if (curSState == 0) //DA1A2
			{
				//Excitation 1
				auto iEx = 0;

				gsl_matrix_complex_set_zero(pmat_diag[0][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][2][iLife]);

				gsl_matrix_complex_set_zero(pmat_diag[1][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][2][iLife]);

				for (mwSize i = 0; i < numSb; i++) {
					//DA1A2


					auto iState = 0;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], i, i, gsl_r2c(eff2s1[i]));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], i, i, gsl_r2c(eff1s1[i]));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c((1 - eff1s1[i] - eff2s1[i]) * pLifeOne));

					//DA1
					iState = 1;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], numSb + i, numSb + i, gsl_r2c(effs2[i] * effD12));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], numSb + i, numSb + i, gsl_r2c(effs2[i] * (1 - effD12)));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c((1 - effs2[i])* pLifeOne));

					//DA2
					iState = 2;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effs3[i]));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effD1*(1 - effs3[i])));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c((1 - effD1)*(1 - effs3[i])* pLifeOne));

					//D only
					iState = 3;
					pLifeOne = pLife(iLife, A1[iEx][iState][0], tau1[iEx][iState][0], tau2[iEx][iState][0], t0[iEx], irfp[iEx], irfc[iEx], 0); //use donly of the folded.
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD2));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD1));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c((1 - effD1 - effD2)* pLifeOne));
				}

				//Excitation 2
				iEx = 1;

				for (mwSize i = 0; i < numSb; i++) {

					//DA2
					auto iState = 2;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum2[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(A2gamma*E12D*pLifeOne)); //A2 direct excitation by acceptor laser
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(A2gamma*(1 - E12D)*pLifeOne));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(0));//donor photons are removed from the trajectories
					double tA2_0 = tau1[iEx][iState][i];

					//DA1A2
					 iState = 0;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeTwo = pLife2(iLife, 1, tA2[i], tA2_0, t0_A2, irfp_A2, irfc_A2, 0);
					pLifeSum2[i][iState] += pLifeOne;
					pLifeSumA2[i] += pLifeTwo;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], i, i, gsl_r2c(eff12s1[i]*pLifeTwo));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], i, i, gsl_r2c((1 - eff12s1[i])*pLifeOne));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], i, i, gsl_r2c(0));//donor photons are removed from the trajectories

					//DA1
					iState = 1;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum2[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], numSb + i, numSb + i, gsl_r2c(effD12*pLifeOne)); //leakage
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], numSb + i, numSb + i, gsl_r2c((1 - effD12)*pLifeOne));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], numSb + i, numSb + i, gsl_r2c(0));//donor photons are removed from the trajectories

					//D only
					iState = 3;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effdA2bgEx2 / (effdA2bgEx2 + effdA1bgEx2) / numLife));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effdA1bgEx2 / (effdA2bgEx2 + effdA1bgEx2)/numLife));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(0)); //donor photons are removed from the trajectories
				}
			}
			else if (curSState == 1) //DA1
			{
				auto iEx = 0;
				gsl_matrix_complex_set_zero(pmat_diag[0][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][2][iLife]);

				gsl_matrix_complex_set_zero(pmat_diag[1][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][2][iLife]);
				for (mwSize i = 0; i < numSb; i++) {
					auto iState = 1;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], i, i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], i, i, gsl_r2c(effs2[i]));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c((1 - effs2[i])*pLifeOne));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], i, i, gsl_r2c(0)); //leakage
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], i, i, gsl_r2c((1)));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], i, i, gsl_r2c(bgRate));

					//D only
					iState = 3;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], numSb + i, numSb + i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], numSb + i, numSb + i, gsl_r2c(effD1 + effD2));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c((1 - effD1 - effD2)*pLifeOne));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], numSb + i, numSb + i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], numSb + i, numSb + i, gsl_r2c(1));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], numSb + i, numSb + i, gsl_r2c(0));
				}
			}
			else if (curSState == 2) //DA2
			{
				auto iEx = 0;
				gsl_matrix_complex_set_zero(pmat_diag[0][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[0][2][iLife]);

				gsl_matrix_complex_set_zero(pmat_diag[1][0][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][1][iLife]);
				gsl_matrix_complex_set_zero(pmat_diag[1][2][iLife]);

				for (mwSize i = 0; i < numSb; i++) {
					/*
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], i, i, gsl_r2c(effs3[i]));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], i, i, gsl_r2c(effD1*(1 - effs3[i])));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c((1 - effD1)*(1 - effs3[i])));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], i, i, gsl_r2c(A2gamma*E12D)); //A2 direct excitation FRET
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], i, i, gsl_r2c(A2gamma*(1 - E12D)));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], i, i, gsl_r2c(bgRate));

					//D only
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], numSb + i, numSb + i, gsl_r2c(effD2));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], numSb + i, numSb + i, gsl_r2c(effD1));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c(1 - effD1 - effD2));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], numSb + i, numSb + i, gsl_r2c(bgRate));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], numSb + i, numSb + i, gsl_r2c(bgRate));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], numSb + i, numSb + i, gsl_r2c(bgRate));
					*/
					auto iState = 2;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], i, i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], i, i, gsl_r2c(effs3[i] + effD1*(1 - effs3[i])));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c((1 - effD1)*(1 - effs3[i])*pLifeOne));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], i, i, gsl_r2c(0)); //A2 direct excitation FRET
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], i, i, gsl_r2c(A2gamma*(1)));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], i, i, gsl_r2c(0));

					//D only
					iState = 3;
					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeSum[i][iState] += pLifeOne;
					gsl_matrix_complex_set(pmat_diag[0][0][iLife], numSb + i, numSb + i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[0][1][iLife], numSb + i, numSb + i, gsl_r2c(effD1 + effD2));
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c((1 - effD1 - effD2)*pLifeOne));

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], numSb + i, numSb + i, gsl_r2c(0));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], numSb + i, numSb + i, gsl_r2c(1));
					gsl_matrix_complex_set(pmat_diag[1][2][iLife], numSb + i, numSb + i, gsl_r2c(0));
				}
			}
		}


		//Normalize lifetime p
		for (auto iLife = 0; iLife < numLife; iLife++) {
			if (curSState == 0) //DA1A2
			{
				//Excitation 1
				auto iEx = 0;

				for (mwSize i = 0; i < numSb; i++) {
					//DA1A2
					auto iState = 0;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife],i,i))/pLifeSum[i][iState]*(1-bkg[iEx])+bkg[iEx]/numLife));

					//DA1
					iState = 1;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], numSb + i, numSb + i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));


					//D only
					iState = 3;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], 3 * numSb + i, 3 * numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], 3 * numSb + i, 3 * numSb + i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));
				}

				//Excitation 2
				iEx = 1;

				for (mwSize i = 0; i < numSb; i++) {
					//DA2
					auto iState = 2;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[1][0][iLife], 2 * numSb + i, 2 * numSb + i)) / pLifeSum2[i][iState] * (1 - bkg_A2) + bkg_A2 / numLife));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], 2 * numSb + i, 2 * numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[1][1][iLife], 2 * numSb + i, 2 * numSb + i)) / pLifeSum2[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));
					double tA2_0 = tau1[iEx][iState][i];

					//DA1A2
					iState = 0;
					double A2portion = eff12s1[i] - (1 - eff12s1[i]) / (1 - effD12)*effD12;
					double A1portion = (1 - eff12s1[i]) / (1 - effD12)*effD12;
					double A2total = A1portion + A2portion;

					pLifeOne = pLife(iLife, A1[iEx][iState][i], tau1[iEx][iState][i], tau2[iEx][iState][i], t0[iEx], irfp[iEx], irfc[iEx], 0);
					pLifeTwo = pLife2(iLife, 1, tA2[i], tA2_0, t0_A2, irfp_A2, irfc_A2, 0);

					double pLifeTwo_cor = (pLifeTwo / pLifeSumA2[i] * A2portion + pLifeOne / pLifeSum2[i][iState] * A1portion) / A2total * (1 - bkg_A2) + bkg_A2 / numLife;

					gsl_matrix_complex_set(pmat_diag[1][0][iLife], i, i, gsl_r2c(eff12s1[i] * pLifeTwo_cor));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], i, i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[1][1][iLife], i, i)) / pLifeSum2[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));

					//DA1
					iState = 1;
					gsl_matrix_complex_set(pmat_diag[1][0][iLife], numSb + i, numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[1][0][iLife], numSb + i, numSb + i)) / pLifeSum2[i][iState] * (1 - bkg_A2) + bkg_A2 / numLife));
					gsl_matrix_complex_set(pmat_diag[1][1][iLife], numSb + i, numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[1][1][iLife], numSb + i, numSb + i)) / pLifeSum2[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));
					

				}
			}
			else if (curSState == 1) //DA1
			{
				auto iEx = 0;
				for (mwSize i = 0; i < numSb; i++) {
					auto iState = 1;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], i, i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));

					//D only
					iState = 3;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], numSb + i, numSb + i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));
					
				}
			}
			else if (curSState == 2) //DA2
			{
				auto iEx = 0;
				
				for (mwSize i = 0; i < numSb; i++) {
					auto iState = 2;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], i, i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], i, i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));

					//D only
					iState = 3;
					gsl_matrix_complex_set(pmat_diag[0][2][iLife], numSb + i, numSb + i, gsl_r2c(GSL_REAL(gsl_matrix_complex_get(pmat_diag[0][2][iLife], numSb + i, numSb + i)) / pLifeSum[i][iState] * (1 - bkg[iEx]) + bkg[iEx] / numLife));
				}
			}
		}
		/* Customization ends */

		mwSize kk = curSState;
		mwSize numS2 = numS;
		if (curSState != 0) numS2 = numS / 2;
		//change to eigenspace coordinate
		for (mwSize i = 0; i < numC; i++)
			for (mwSize j=0;j<numEx;j++)
			{
				for (auto iLife = 0; iLife < numLife; iLife++) {
					gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, pmat_diag[j][i][iLife], eigen_mat[kk], GSL_COMPLEX_ZERO, pmat[j][i][iLife]);
					gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat[kk], pmat[j][i][iLife], GSL_COMPLEX_ZERO, pmat_diag[j][i][iLife]);
				}
			}

		for (mwSize i = 0; i < numS2; i++)
		{
			gsl_vector_complex_set(probonesub[kk], i, gsl_r2c(gsl_vector_get(peq[kk], i)));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat[kk], probonesub[kk], GSL_COMPLEX_ZERO, probonesub_t[kk]);

		logamp = 0;

		//for burst length
		for (mwSize ii = mwSize(cumindex[mwSize(indexone[k] - 1)]); ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit
			photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);
			delay_time = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 2) + ii]);

			if (curSState != 2 && photon_color == 2) photon_color = 3; //for 2-color segs DA2 set acceptor 1 photons to donor
			if (curSState != 0 && photon_color == 1) photon_color = 2; //for 2-color segs set acceptor 2 photons to acceptor1
			//set ratemat value
			for (mwSize i = 0; i < numS2; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_values[curSState], i), photon_interval));
				gsl_matrix_complex_set(ratemat[curSState], i, i, exponent);
				//gsl_vector_complex_set(&(ratemat_diag_view[curSState].vector), i, exponent);
			}
			//E x probonesub. Instead of ratemat X E, run matrix X vector for a better performance
			
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pmat_diag[mwSize(exid[ii])-1][photon_color - 1][delay_time], probonesub_t[curSState], GSL_COMPLEX_ZERO, probonesub[curSState]);

			//K * (E x probonesub)
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat[curSState], probonesub[curSState], GSL_COMPLEX_ZERO, probonesub_t[curSState]);

			if (( (ii - mwSize(cumindex[mwSize(indexone[k] - 1)])) + 1) % 10 == 0) //check for every 10. Increased number of parameter may decrease probone faster... is it?
			{
				normprobone = gsl_vector_complex_norm(probonesub_t[curSState]);
				gsl_vector_complex_scale(probonesub_t[curSState], gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}
		}

		//the last photon color
		photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)]);
		delay_time = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 2) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)]);
		if (curSState != 0 && photon_color == 1) photon_color = 2;
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, pmat_diag[mwSize(exid[mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)]) - 1][photon_color - 1][delay_time], probonesub[curSState], GSL_COMPLEX_ZERO, probonesub_t[curSState]);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_mat[curSState], probonesub_t[curSState], GSL_COMPLEX_ZERO, probonesub[curSState]);

		mt_param->probeone += -log(gsl_vector_complex_sum(probonesub[curSState])) - logamp;
	}

	for (auto iEx = 0; iEx < numEx; iEx++)
	{
		for (auto iState = 0; iState<numSState + 1; iState++)
		{
			delete(A1[iEx][iState]);
			delete(tau1[iEx][iState]);
			delete(tau2[iEx][iState]);
		}
		delete(A1[iEx]);
		delete(tau1[iEx]);
		delete(tau2[iEx]);
	}
	delete(A1);
	delete(tau1);
	delete(tau2);

	return 0;
}

//bool updatePmat(double * irfparams, double donlylife, double Dlif1, double Dlife2, double *pMat, mwSize pmatLen, )

double pLife(mwSize iLife, double A1, double tau1, double tau2, double x0, double irfp, double irfc, double bkg) //returns probability for a given delaytime
{
	if (iLife < x0) return bkg;

	auto A2 = 1 - A1;
	A1 *= (1 - bkg);
	A2 *= (1 - bkg);
	auto p = irfp;
	auto c = irfc;

	double A1portion{ 0 };
	if ((c - 1 / tau1) > 0)
	{
		A1portion = A1*pow(c / (c - 1 / tau1), p)*exp(-(iLife - x0) / tau1)*gsl_sf_gamma_inc_Q((iLife - x0)*(c - 1 / tau1), p);
	}
	
	double A2portion{ 0 };
	if ((c - 1 / tau2) > 0)
	{
		A2portion = A2*pow(c / (c - 1 / tau2), p)*exp(-(iLife - x0) / tau2)*gsl_sf_gamma_inc_Q((iLife - x0)*(c - 1 / tau2), p);
	}	

	auto prob = A1portion + A2portion + bkg;

	return prob;
}

double pLife2(mwSize iLife, double A1, double tauD, double tauA, double x0, double irfp, double irfc, double bkg) //returns probability for a given delaytime
{
	if (iLife < x0) return bkg;

	//auto A2 = 1 - A1;
	A1 *= (1 - bkg);
	//A2 *= (1 - bkg);
	auto p = irfp;
	auto c = irfc;

	double A1portion{ 0 };
	if ((c - 1 / tauA) > 0)
	{
		A1portion = A1/(tauA-tauD)*pow(c / (c - 1 / tauA), p)*exp(-(iLife - x0) / tauA)*gsl_sf_gamma_inc_Q((iLife - x0)*(c - 1 / tauA), p);
	}

	double A2portion{ 0 };
	if ((c - 1 / tauD) > 0)
	{
		A2portion = A1 / (tauA - tauD)*pow(c / (c - 1 / tauD), p)*exp(-(iLife - x0) / tauD)*gsl_sf_gamma_inc_Q((iLife - x0)*(c - 1 / tauD), p);
	}

	auto prob = A1portion - A2portion;

	return prob;
}