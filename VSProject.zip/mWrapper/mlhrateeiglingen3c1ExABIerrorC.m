function [errorparams logmlh1 bic]=mlhrateeiglingen3c1ExABIerrorC(initparams,fixparam,frburstdata,cumindex,indexone,isfastbinding,isA2bleach,ubid,stateid,chans,drvintv,drvpnt)
% Beacuse evaluating mlhratesub takes long time, substitute this
% sub-routine to a C-translated version.

if size(initparams,1) < size(initparams,2) % It should be a column vector
    initparams=initparams';
end

drvintvs=1+drvintv*(-drvpnt:drvpnt);

    donchan=chans(3);
    ac1chan=chans(2);
    ac2chan=chans(1);

    frburstdata1=frburstdata{1};
    cumindex1=cumindex{1};
    indexone1=indexone{1};
    donid=find(frburstdata1(:,end) == donchan);
    ac1id=find(frburstdata1(:,end) == ac1chan);
    frburstdata1(:,end)=1;
    frburstdata1(ac1id,end)=2;
    frburstdata1(donid,end)=3;  % Convert colors for 3-color analysis
    
    fixparam1=[fixparam{1}; fixparam{2}; fixparam{3}; fixparam{4}];
    cntrate1=zeros(length(indexone1),1);
    for kk=1:length(indexone1);
        oneburst1=frburstdata1(cumindex1(indexone1(kk))+1:cumindex1(indexone1(kk)+1),:);
        photoninterval1=diff(oneburst1(:,end-2))*1e-4;        % in ms
        cntrate1(kk)=1/mean(photoninterval1);
    end
    numphotons=sum(cumindex1(indexone1+1)-cumindex1(indexone1));

    if isfastbinding,
        if all (stateid == [1 3]),
            nstate=(length(initparams)-2-isA2bleach)/6;
            frburstdata2=frburstdata{2};
            cumindex2=cumindex{2};
            indexone2=indexone{2};
            ac2id=find(frburstdata2(:,end) == ac2chan);
            frburstdata2(:,end)=2;
            frburstdata2(ac2id,end)=1;  % Convert colors for 2-color analysis
            numphotons=numphotons+sum(cumindex2(indexone2+1)-cumindex2(indexone2));
        else
            nstate=(length(initparams)-2-isA2bleach)/5;
        end
    else
        nstate=(length(initparams)-2)/(length(stateid)+3);
        if any(stateid == 2),
            frburstdata2=frburstdata{2};
            cumindex2=cumindex{2};
            indexone2=indexone{2};
            donid=find(frburstdata2(:,end) == donchan);
            frburstdata2(:,end)=1;
            frburstdata2(donid,end)=2;  % Convert colors for 2-color analysis
            numphotons=numphotons+sum(cumindex2(indexone2+1)-cumindex2(indexone2));
        end            
        if any(stateid == 3),
            frburstdata3=frburstdata{3};
            cumindex3=cumindex{3};
            indexone3=indexone{3};
            ac2id=find(frburstdata3(:,end) == ac2chan);
            frburstdata3(:,end)=2;
            frburstdata3(ac2id,end)=1;  % Convert colors for 2-color analysis
            numphotons=numphotons+sum(cumindex3(indexone3+1)-cumindex3(indexone3));
        end        
    end
    
initparammat=[];peqmat=[];
for kk=1:length(initparams)
    for nn=1:length(drvintvs)
        initparamone=initparams;
        initparamone(kk)=initparams(kk)*drvintvs(nn);
        peqtemp=initparamone(end-nstate-2:end-4);
        peqmat=[peqmat peqtemp];
        frn=zeros(size(peqtemp));
        frn(1)=peqtemp(1);
        for jj=1:nstate-2;
            fdiv=prod(1-frn(1:jj));
            frn(jj+1)=peqtemp(jj+1)/fdiv;
        end
        initparamone(end-nstate-2:end-4)=frn;
        initparammat=[initparammat initparamone];
    end
end

for kk=1:length(initparams)
    for mm=kk+1:length(initparams)
        for nn=1:length(drvintvs)
            initparamone=initparams;
            initparamone(kk)=initparams(kk)*drvintvs(nn);initparamone(mm)=initparams(mm)*drvintvs(nn);
            peqtemp=initparamone(end-nstate-2:end-4);
            peqmat=[peqmat peqtemp];
            frn=zeros(size(peqtemp));
            frn(1)=peqtemp(1);
            for jj=1:nstate-2;
                fdiv=prod(1-frn(1:jj));
                frn(jj+1)=peqtemp(jj+1)/fdiv;
            end
            initparamone(end-nstate-2:end-4)=frn;
            initparammat=[initparammat initparamone];
        end
    end
end
peqmat=[peqmat; 1-sum(peqmat,1)];

LUbounds=[initparammat(:,(length(drvintvs)+1)/2)*0.8 initparammat(:,(length(drvintvs)+1)/2)*1.2]; % dummy LUbounds

        effb1=fixparam{1}(1);  % E1 of A1,A2 dark state (= A1/(A2 + A1 + D))
        effb2=fixparam{1}(2);  % E2 of A1,A2 dark state (= A2/(A2 + A1 + D)) (depends on the A2-protein concentration)
        
        effs2=fixparam{2};  % Pre-determined E_DA1 (= (A1+A2)/(D+A1+A2)) will be used unless modified below using fitting parameters
        effs3=fixparam{3};  % Pre-determined E_DA2 (= A2/(D+A1+A2)) will be used unless modified below using fitting parameters
        effb12=fixparam{4};  % E12 when no A2: A1 leak into A2 channel

        if isfastbinding,
            if all (stateid == [1 3]),
                initparamtemp=initparammat;
                effs3mat=initparamtemp(3*nstate:4*nstate-1,:);
                ratesummat=initparammat(end-2*nstate-1:end-nstate-3,:);
                labelFmat=initparamtemp(4*nstate,:);       % labeling efficiency of A2
                if isA2bleach == 1, A2bratemat=initparamtemp(4*nstate+1,:); end     % Rate for A2 bleaching or blinking
                if isA2bleach == 2,     % For the case of no detailed balance of A2 bleaching and blinking
                    labelFappmat=initparamtemp(4*nstate+1,:);
                    A2bratemat=initparamtemp(4*nstate+2,:);
                end
                ktobrtmat=initparamtemp(end-3:end-2,:);
                frnb0mat=initparamtemp(end-1:end,:);
                effb2mat=effs3mat(ubid,:);
                initparamtemp(3*nstate:4*nstate-1,:)=[];
                LUboundsdummy=[initparamtemp(:,(length(drvintvs)+1)/2)*0.8 initparamtemp(:,(length(drvintvs)+1)/2)*1.2];
                logmlh=zeros(size(initparamtemp,2),1);
                for jj=1:size(initparamtemp,2);
                    fixparamnew=[effb1; effs3mat(ubid,jj); effs2; effs3mat(:,jj); effb12];
                    if isA2bleach < 2,
                        logmlh(jj)=mlhrateeiglingen3c1ExBindABI_MT([initparamtemp(:,jj) initparamtemp(:,jj)],LUboundsdummy,frburstdata1,cumindex1,indexone1,cntrate1,fixparamnew,ubid);
                    else
                        logmlh(jj)=mlhrateeiglingen3c1ExBindnoDBABI_MT([initparamtemp(:,jj) initparamtemp(:,jj)],LUboundsdummy,frburstdata1,cumindex1,indexone1,cntrate1,fixparamnew,ubid);
                    end
                end
                                
                cntrate=zeros(length(indexone2),1);
                for k=1:length(indexone2)
                    oneburst=frburstdata2(cumindex2(indexone2(k))+1:cumindex2(indexone2(k)+1),:);
                    photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
                    cntrate(k)=1/mean(photoninterval);
                end
                
              for hh=1:size(initparammat,2);
                ratemat0=zeros(2*nstate-1);
                ratesum=ratesummat(:,hh);
                peq=peqmat(:,hh);
                effs3=effs3mat(:,hh);
                labelF=labelFmat(hh);
                if isA2bleach == 2, labelFapp=labelFappmat(hh); end
                A2brate=A2bratemat(hh);
                ktobrt=ktobrtmat(:,hh);
                frnb0=frnb0mat(:,hh);
                effb2=effb2mat(hh);

                for jj=1:nstate-1;
                    peqtemp=peq(jj:jj+1)/sum(peq(jj:jj+1));
                    ratemat0(jj:jj+1,jj:jj+1)=ratemat0(jj:jj+1,jj:jj+1)+ratesum(jj)*[-peqtemp(2) peqtemp(1);peqtemp(2) -peqtemp(1)];
                end
                ratemat1=ratemat0(1:nstate,1:nstate);
                ratemat0(:,ubid)=ratemat0(:,ubid)*labelF;
                ratemat1(:,ubid)=ratemat1(:,ubid)*(1-labelF);
                A2darkStid=nstate+1:2*nstate;
                A2darkStid(ubid+1:end)=A2darkStid(ubid+1:end)-1;
                A2darkStid(ubid)=ubid;
                ratemat0(A2darkStid,A2darkStid)=ratemat0(A2darkStid,A2darkStid)+ratemat1;
                peqfb=[peq*labelF; peq*(1-labelF)];
                peqfb(ubid)=peqfb(ubid)+peqfb(ubid+nstate);
                peqfb(nstate+ubid)=[];
                if isA2bleach,
                    brateaddid=1:nstate;
                    brateaddid(ubid)=[];
                    for jj=brateaddid;
                        if isA2bleach < 2,
                            ratemat0([jj A2darkStid(jj)],[jj A2darkStid(jj)])=ratemat0([jj A2darkStid(jj)],[jj A2darkStid(jj)])+A2brate*[-(1-labelF) labelF; 1-labelF -labelF];
                        else
                            ratemat0([jj A2darkStid(jj)],[jj A2darkStid(jj)])=ratemat0([jj A2darkStid(jj)],[jj A2darkStid(jj)])+A2brate*[-(1-labelFapp) labelFapp; 1-labelFapp -labelFapp];
                        end
                    end
                end
                
                effs3New=[effs3; repmat(effs3(ubid),size(effs3,1)-1,1)];
            
                pinput=[peqfb peqfb ones(size(peqfb))];     % First column is not used. Second is equilibrium population and the third is summation over states in the likelihood calculation

                inputparam=[effs3New; effb2; ktobrt(2); frnb0(2)];
                LUboundsdummy=[min(inputparam,[],2)*0.8 max(inputparam,[],2)*1.2]; % dummy LUbounds
                logmlh(hh)=logmlh(hh)+mlhTPgenABIcal([inputparam inputparam],LUboundsdummy,frburstdata2,cumindex2,indexone2,cntrate,ratemat0,pinput);
              end
            else
                if isA2bleach < 2,
                    logmlh=mlhrateeiglingen3c1ExBindABI_MT(initparammat,LUbounds,frburstdata1,cumindex1,indexone1,cntrate1,fixparam1,ubid);
                else
                    logmlh=mlhrateeiglingen3c1ExBindnoDBABI_MT(initparammat,LUbounds,frburstdata1,cumindex1,indexone1,cntrate1,fixparam1,ubid);
                end
            end
        else
            % 3-color segment likelihood
            if all(stateid == 1),
                logmlh=mlhrateeiglingen3c1ExABI_MT(initparammat,LUbounds,frburstdata1,cumindex1,indexone1,cntrate1,fixparam1);
            end
            if any(stateid == 2),       % 2-color (DA1) segment likelihood
                cntrate=zeros(length(indexone2),1);
                for k=1:length(indexone2)
                    oneburst=frburstdata2(cumindex2(indexone2(k))+1:cumindex2(indexone2(k)+1),:);
                    photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
                    cntrate(k)=1/mean(photoninterval);
                end
                effs2mat=initparammat(2*nstate+1:3*nstate,:);
                % For the case of the definition, E2 = A2/(D+A2)
%                 initparamtemp=[effs2mat; repmat(1-(1-effb1)*(1-effb2)/(1-effb1*effb2),1,size(initparammat,2)); initparammat(end-2*nstate-1:end-4,:); initparammat([end-3 end-1],:)];
                % For the case of the definition, E2 = A2/(D+A1+A2)
                initparamtemp=[effs2mat; repmat(effb1,1,size(initparammat,2)); initparammat(end-2*nstate-1:end-4,:); initparammat([end-3 end-1],:)];
                LUboundsdummy=[initparamtemp*0.8 initparamtemp*1.2]; % dummy LUbounds
                logmlh=logmlh+mlhrateeiglingenABI_MT(initparamtemp,LUboundsdummy,frburstdata2,cumindex2,indexone2,cntrate);
            end
            if any(stateid == 3),       % 2-color (DA2) segment likelihood
                cntrate=zeros(length(indexone3),1);
                for k=1:length(indexone3)
                    oneburst=frburstdata3(cumindex3(indexone3(k))+1:cumindex3(indexone3(k)+1),:);
                    photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
                    cntrate(k)=1/mean(photoninterval);
                end
                effs3mat=initparammat(3*nstate+1:4*nstate,:);
                initparamtemp=[effs3mat; repmat(effb2,1,size(initparammat,2)); initparammat(end-2*nstate-1:end-4,:); initparammat([end-2 end],:)];
                LUboundsdummy=[initparamtemp*0.8 initparamtemp*1.2]; % dummy LUbounds
                logmlh=logmlh+mlhrateeiglingenABI_MT(initparamtemp,LUboundsdummy,frburstdata3,cumindex3,indexone3,cntrate);
            end
        end
        
Hessianmat=zeros(length(initparams),length(initparams));
logmlhdiag=zeros(1,length(drvintvs));

mlhIndex=1;
for kk=1:length(initparams)
    logmlhdiag=logmlhdiag*0;
    for nn=1:length(drvintvs)
        logmlhdiag(nn)=logmlh(mlhIndex);
        mlhIndex=mlhIndex+1;
    end
    diagcoeff=polyfit(drvintvs,logmlhdiag,2);
    Hessianmat(kk,kk)=diagcoeff(1)/initparams(kk)^2;
end

logmlhoffdiag=zeros(1,length(drvintvs));
for kk=1:length(initparams)
    for mm=kk+1:length(initparams)
        logmlhoffdiag=logmlhoffdiag*0;
        for nn=1:length(drvintvs)
            logmlhoffdiag(nn)=logmlh(mlhIndex);
            mlhIndex=mlhIndex+1;
        end
        offdiagcoeff=polyfit(drvintvs,logmlhoffdiag,2);
        Hessianmat(kk,mm)=(offdiagcoeff(1)-Hessianmat(kk,kk)*initparams(kk)^2-Hessianmat(mm,mm)*initparams(mm)^2)/2/initparams(kk)/initparams(mm);
        Hessianmat(mm,kk)=Hessianmat(kk,mm);
    end
end

covmat=inv(2*Hessianmat);
errorparams=sqrt(diag(covmat));

logmlh1=-logmlhdiag((length(drvintvs)+1)/2);
bic=-2*logmlh1 + length(initparams)*log(numphotons);

end