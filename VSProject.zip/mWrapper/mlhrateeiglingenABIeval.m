function [ logmlh ] = mlhrateeiglingenABIeval( data, initparams )
%mlhrateeiglingenABIeval Evaluation function for MCS optimization of 
% mlhrateeiglingenABI.
%   [ logmlh ] = mlhrateeiglingenABImcs( data, param )

LUbounds=data{1};
frburstdata=data{2};
cumindex=data{3};
indexone=data{4};
cntrate=data{5};
donlyfret=data{6};

nstate = length(initparams)/3;

initparamsNew=zeros(3*nstate+1,1);
LUboundsNew=zeros(3*nstate+1,2);
initparamsNew(1:nstate)=initparams(1:nstate); %Eff
LUboundsNew(1:nstate,:)=LUbounds(1:nstate,:);
initparamsNew(nstate+1)=donlyfret; %EffD
LUboundsNew(nstate+1,:)=[initparamsNew(nstate+1)*0.999 initparamsNew(nstate+1)*1.001];
%LUboundsNew(3,:)=[0.01 0.09];
initparamsNew(nstate+2:end)=initparams(nstate+1:end); %ratesum, fr, kb, frb
LUboundsNew(nstate+2:end,:)=LUbounds(nstate+1:end,:);

logmlh=mlhrateeiglingenABImcs_MT(initparamsNew,LUboundsNew,frburstdata,cumindex,indexone,cntrate);

end

