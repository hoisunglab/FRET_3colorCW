function [errorparams logmlh1 bic]=mlhrateeiglingenABIerrorC(initparams,frburstdata,cumindex,indexone,drvintv,drvpnt,donlyfret)
% Beacuse evaluating mlhratesub takes long time, substitute this
% sub-routine to a C-translated version.
if nargin<7
    donlyfret=0.06;
end
if size(initparams,1) < size(initparams,2) % It should be a column vector
    initparams=initparams';
end

cntrate=zeros(length(indexone),1);
for k=1:length(indexone)
    oneburst=frburstdata(cumindex(indexone(k))+1:cumindex(indexone(k)+1),:);
    photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
    cntrate(k)=1/mean(photoninterval);
end

% Convert initparams to C version...

nstate = length(initparams)/3;

initparamsNew=zeros(3*nstate+1,1);
initparamsNew(1:nstate)=initparams(1:nstate); %Eff
initparamsNew(nstate+1)=donlyfret; %EffD
initparamsNew(nstate+2:end)=initparams(nstate+1:end); %ratesum, fr, kb, frb

initparams=initparamsNew;

drvintvs=1+drvintv*(-drvpnt:drvpnt);

initparammat=[];
for kk=1:length(initparams)
    for nn=1:length(drvintvs)
        initparamone=initparams;
        initparamone(kk)=initparams(kk)*drvintvs(nn);
        peqtemp=initparamone(2*nstate+1:end-2);
        frn=zeros(size(peqtemp));
        frn(1)=peqtemp(1);
        for jj=1:nstate-2
            frn(jj+1)=peqtemp(jj+1)/(1-frn(jj));
        end
        initparamone(2*nstate+1:end-2)=frn;
        initparammat=[initparammat initparamone];
    end
end

for kk=1:length(initparams)
    for mm=kk+1:length(initparams)
        for nn=1:length(drvintvs)
            initparamone=initparams;
            initparamone(kk)=initparams(kk)*drvintvs(nn);initparamone(mm)=initparams(mm)*drvintvs(nn);
            peqtemp=initparamone(2*nstate+1:end-2);
            frn=zeros(size(peqtemp));
            frn(1)=peqtemp(1);
            for jj=1:nstate-2
                frn(jj+1)=peqtemp(jj+1)/(1-frn(jj));
            end
            initparamone(2*nstate+1:end-2)=frn;
            initparammat=[initparammat initparamone];
        end
    end
end

LUbounds=[initparammat(:,(length(drvintvs)+1)/2)*0.8 initparammat(:,(length(drvintvs)+1)/2)*1.2]; % dummy LUbounds
logmlh=mlhrateeiglingenABI_MT(initparammat,LUbounds,frburstdata,cumindex,indexone,cntrate);

Hessianmat=zeros(length(initparams),length(initparams));
logmlhdiag=zeros(1,length(drvintvs));

mlhIndex=1;
for kk=1:length(initparams)
    logmlhdiag=logmlhdiag*0;
    for nn=1:length(drvintvs)
        logmlhdiag(nn)=logmlh(mlhIndex);
        mlhIndex=mlhIndex+1;
    end
    diagcoeff=polyfit(drvintvs,logmlhdiag,2);
    Hessianmat(kk,kk)=diagcoeff(1)/initparams(kk)^2;
end

logmlhoffdiag=zeros(1,length(drvintvs));
for kk=1:length(initparams)
    for mm=kk+1:length(initparams)
        logmlhoffdiag=logmlhoffdiag*0;
        for nn=1:length(drvintvs)
            logmlhoffdiag(nn)=logmlh(mlhIndex);
            mlhIndex=mlhIndex+1;
        end
        offdiagcoeff=polyfit(drvintvs,logmlhoffdiag,2);
        Hessianmat(kk,mm)=(offdiagcoeff(1)-Hessianmat(kk,kk)*initparams(kk)^2-Hessianmat(mm,mm)*initparams(mm)^2)/2/initparams(kk)/initparams(mm);
        Hessianmat(mm,kk)=Hessianmat(kk,mm);
    end
end

% Remove donlyfret parts
Hessianmat(:,nstate+1)=[];
Hessianmat(nstate+1,:)=[];

covmat=inv(2*Hessianmat);
errorparams=sqrt(diag(covmat));

%errorparamsNew=sqrt(diag(covmat));
%errorparams=zeros(3*nstate,1);
%errorparams(1:nstate)=errorparamsNew(1:nstate);
%errorparams(nstate+1:end)=errorparamsNew(nstate+2:end);

logmlh1=-logmlhdiag((length(drvintvs)+1)/2);
numphotons=sum(cumindex(indexone+1)-cumindex(indexone));
bic=-2*logmlh1 + length(initparams)*log(numphotons);
end