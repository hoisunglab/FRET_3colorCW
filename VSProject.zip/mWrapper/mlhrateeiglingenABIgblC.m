function respconv=mlhrateeiglingenABIgblC(initparams,LUbounds,frburstdata,cumindex,indexone,conc,ubid,donlyfret)
% A global fit of a set of data with different concentrations of binding partner using mlhrateeiglingenABI_MT.
% initparams in MATLAB = [Effn; ratesumn; p1s or Cds; ktobrt frnb0]
% p1(i) is the relative population of the first state of the two states
% (i and i+1) connected by ratesumn(i).
% Cd(1) and Cd(2) are dissociation constansts between unbound state
% (indicated by ubid) and the states before (ubid-1) and after (ubid+1).
% If ubid = 1 or n, there is only one Cd.
% initparams in C = [Effn EffD ratesumn frn ktobrt frnb0]
% Also, count rates will be passed from MATLAB to C

    function logmlh=mlhratesub(params)
        pconv=diff(LUbounds,1,2)./(1+params.^2)+LUbounds(:,1);
        effn=pconv(1:nstate);
        ratesumn=pconv(nstate+1:2*nstate-1);

        p1Cd=pconv(2*nstate:end-2);
        Adarkparams=pconv(end-1:end);
        
        ratesumF=ratesumn.*(1-p1Cd);
        ratesumB=ratesumn.*p1Cd;
        
        logmlh=0;
        for ccc=1:length(conc);
            if ubid < nstate,      % Association rate depends on the concentration
                ratesumF(ubid)=ratesumn(ubid)/2*conc(ccc)/p1Cd(ubid);
                ratesumB(ubid)=ratesumn(ubid)/2;
            end
            if ubid > 1,      % Association rate depends on the concentration
                ratesumF(ubid-1)=ratesumn(ubid-1)/2;
                ratesumB(ubid-1)=ratesumn(ubid-1)/2*conc(ccc)/p1Cd(ubid-1);
            end
            ratesumNew=ratesumF+ratesumB;
            peqtemp=cumprod([1; ratesumF./ratesumB]);
            peqNew=peqtemp/sum(peqtemp);
            frnNew=zeros(size(peqNew));
            frnNew(1)=peqNew(1);
            for jj=1:nstate-2;
                fdiv=prod(1-frnNew(1:jj));
                frnNew(jj+1)=peqNew(jj+1)/fdiv;
            end
            frnNew(end)=[];
            
            initparamsNew=[effn; donlyfret; ratesumNew; frnNew; Adarkparams];
            LUboundsdummy=[initparamsNew*0.9 initparamsNew*1.1];
            logmlh=logmlh+mlhrateeiglingenABI_MT([initparamsNew initparamsNew],LUboundsdummy,frburstdata{ccc},cumindex{ccc},indexone{ccc},cntrate{ccc});
        end
    end

if nargin<8
    donlyfret=0.06;
end

for cc=1:length(conc);
    cntrate{cc}=zeros(length(indexone{cc}),1);
    for k=1:length(indexone{cc})
        oneburst=frburstdata{cc}(cumindex{cc}(indexone{cc}(k))+1:cumindex{cc}(indexone{cc}(k)+1),:);
        photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
        cntrate{cc}(k)=1/mean(photoninterval);
    end
end

nstate = length(initparams)/3;

options=optimset('MaxFunEval', 2000, 'MaxIter', 2000);

invinitparams=sqrt(diff(LUbounds,1,2)./(initparams-LUbounds(:,1))-1);
resparams=fminsearch(@mlhratesub,invinitparams,options);
respconv=diff(LUbounds,1,2)./(1+resparams.^2)+LUbounds(:,1);

end