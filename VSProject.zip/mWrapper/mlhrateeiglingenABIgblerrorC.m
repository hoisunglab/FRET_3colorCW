function [errorparams logmlh1 bic]=mlhrateeiglingenABIgblerrorC(initparams,frburstdata,cumindex,indexone,conc,ubid,drvintv,drvpnt,donlyfret)

    function logmlh=mlhratesub(params)
        effn=params(1:nstate);
        ratesumn=params(nstate+1:2*nstate-1);

        p1Cd=params(2*nstate:end-2);
        Adarkparams=params(end-1:end);
        
        ratesumF=ratesumn.*(1-p1Cd);
        ratesumB=ratesumn.*p1Cd;
        
        logmlh=0;
        for ccc=1:length(conc);
            if ubid < nstate,      % Association rate depends on the concentration
                ratesumF(ubid)=ratesumn(ubid)/2*conc(ccc)/p1Cd(ubid);
                ratesumB(ubid)=ratesumn(ubid)/2;
            end
            if ubid > 1,      % Association rate depends on the concentration
                ratesumF(ubid-1)=ratesumn(ubid-1)/2;
                ratesumB(ubid-1)=ratesumn(ubid-1)/2*conc(ccc)/p1Cd(ubid-1);
            end
            ratesumNew=ratesumF+ratesumB;
            peqtemp=cumprod([1; ratesumF./ratesumB]);
            peqNew=peqtemp/sum(peqtemp);
            frnNew=zeros(size(peqNew));
            frnNew(1)=peqNew(1);
            for jj=1:nstate-2;
                fdiv=prod(1-frnNew(1:jj));
                frnNew(jj+1)=peqNew(jj+1)/fdiv;
            end
            frnNew(end)=[];
            
            initparamsNew=[effn; donlyfret; ratesumNew; frnNew; Adarkparams];
            LUboundsdummy=[initparamsNew*0.9 initparamsNew*1.1];
            logmlh=logmlh+mlhrateeiglingenABI_MT([initparamsNew initparamsNew],LUboundsdummy,frburstdata{ccc},cumindex{ccc},indexone{ccc},cntrate{ccc});
        end
    end

if nargin<9
    donlyfret=0.06;
end

numphotons=0;
for cc=1:length(conc);
    cntrate{cc}=zeros(length(indexone{cc}),1);
    for k=1:length(indexone{cc})
        oneburst=frburstdata{cc}(cumindex{cc}(indexone{cc}(k))+1:cumindex{cc}(indexone{cc}(k)+1),:);
        photoninterval=diff(oneburst(:,end-2))*1e-4; % 1 ms timeunit
        cntrate{cc}(k)=1/mean(photoninterval);
    end
    numphotons=numphotons+sum(cumindex{cc}(indexone{cc}+1)-cumindex{cc}(indexone{cc}));
end

nstate = length(initparams)/3;

drvintvs=1+drvintv*(-drvpnt:drvpnt);

logmlhdiag=zeros(length(initparams),length(drvintvs));
for kk=1:length(initparams);
    clear logmlhdiag
    for nn=1:length(drvintvs);
        initparamone=initparams;
        initparamone(kk)=initparams(kk)*drvintvs(nn);
        logmlhdiag(nn)=mlhratesub(initparamone);
    end
    diagcoeff=polyfit(drvintvs,logmlhdiag,2);
    Hessianmat(kk,kk)=diagcoeff(1)/initparams(kk)^2;
end

for kk=1:length(initparams);
    for mm=kk+1:length(initparams);
        clear logmlhoffdiag
        for nn=1:length(drvintvs);
            initparamone=initparams;
            initparamone(kk)=initparams(kk)*drvintvs(nn);initparamone(mm)=initparams(mm)*drvintvs(nn);
            logmlhoffdiag(nn)=mlhratesub(initparamone);
        end
        offdiagcoeff=polyfit(drvintvs,logmlhoffdiag,2);
        Hessianmat(kk,mm)=(offdiagcoeff(1)-Hessianmat(kk,kk)*initparams(kk)^2-Hessianmat(mm,mm)*initparams(mm)^2)/2/initparams(kk)/initparams(mm);
        Hessianmat(mm,kk)=Hessianmat(kk,mm);
    end
end

covmat=inv(2*Hessianmat);
errorparams=sqrt(diag(covmat));

logmlh1=-logmlhdiag((length(drvintvs)+1)/2);
bic=-2*logmlh1 + length(initparams)*log(numphotons);
end